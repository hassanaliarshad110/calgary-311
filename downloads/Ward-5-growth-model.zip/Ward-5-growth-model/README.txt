Ward 5 growth model - Who Calgary's 311 Hears
By Hassan Ali, October 2026
https://hassanaliarshad110.github.io/calgary-311/ward5.html

WHY
The study measures 311 reporting per resident using 2021 Census population. Communities that
have grown a lot since 2021 (in Ward 5: Cornerstone, Cityscape, Skyview Ranch) therefore look
as if they report far more than they do. This model estimates each community's population
during the study period (October 2024 - September 2026) from the homes people live in.

HOW
1. Homes: every dwelling on the City's 2026 property assessment roll (residential class,
   land with a building, residential use code), by year of construction.
2. A home is counted as lived in one year after its year of construction.
3. People per home: 2021 Census population / homes lived in on Census day (May 11, 2021).
4. Population in each study month = people per home x homes lived in; averaged over 24 months.
5. The study's main model is re-run for all 195 communities with this population.
Check: the method predicts the City's 2019 civic census from its 2016 count
(growth_check_2016_2019.csv).

RUN
  python growth_model.py     -> growth_results.csv, growth_summary.json, growth_check_2016_2019.csv
  python ward5_data.py       -> ward5.json (the figures on the Ward 5 page)
Needs Python 3 with pandas and numpy.

FILES
  homes_by_year_built.csv     dwellings by community and year of construction (2026 roll)
  civic_census.csv            City civic census population by community, 2010-2019
  community_wards.csv         ward for each community
  communities_enriched.csv    311 counts, 2021 Census and area measures by community (main study)
  311_requests_by_community_service.csv   311 requests by community and type (main study)
  SOURCES.csv                 the City open data query behind each input
Data: City of Calgary Open Data, Open Government Licence - City of Calgary.
