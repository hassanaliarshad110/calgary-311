Ward 5 growth model - Who Calgary's 311 Hears
By Hassan Ali, October 2026
https://hassanaliarshad110.github.io/calgary-311/ward5.html

WHY
The study measures 311 reporting per resident using 2021 Census population. Communities that
have grown a lot since 2021 (in Ward 5: Cornerstone, Cityscape, Skyview Ranch) therefore look
as if they report far more than they do. This model estimates each community's population
during the study period (October 2024 - September 2026) from the homes people live in.

HOW
1. Homes: every dwelling on the City's 2026 property assessment roll (residential class,
   land with a building, residential use code), by year of construction.
2. A home is counted as lived in one year after its year of construction.
3. People per home: 2021 Census population / homes lived in on Census day (May 11, 2021).
4. Rental buildings: the roll lists each as one property. Units come from matching building permits
   (address or location on the property), lived in 6 months after the permit is completed; otherwise
   estimated from assessed value and scaled to 2021 Census households. 2.0 people per rental unit, or the
   community's 2021 household size if smaller.
5. People per home (other homes) = (2021 population - people in rental units) / other homes on Census day.
6. Population in each study month = people per home x homes + people per unit x rental units; averaged.
7. The study's main model is re-run for all 195 communities with this population.
8. Check only: births and deaths since 2021 (natural_change_check.py).
Check: the method predicts the City's 2019 civic census from its 2016 count
(growth_check_2016_2019.csv).

RUN
  python rental_units.py     -> rental_units.csv, rental_movein.csv (from rental_matches.json)
  python growth_model.py     -> growth_results.csv, growth_summary.json, growth_check_2016_2019.csv, population_all_communities.csv
  python natural_change_check.py -> natural_change_check.json
  python ward5_data.py       -> ward5.json (the figures on the Ward 5 page)
Needs Python 3 with pandas and numpy.

TWO INPUTS ARE PROVIDED AS FILES ONLY
rental_matches.json (rental buildings on the property roll matched to building permits) and community_wards.csv
(the ward holding most of each community's area) are included as built on October 28, 2026, with their method
described above and in SOURCES.csv. There is no script yet that rebuilds them from Open Data. Every other input
can be re-downloaded with the queries in SOURCES.csv.

FILES
  homes_by_year_built.csv     dwellings by community and year of construction (2026 roll)
  civic_census.csv            City civic census population by community, 2010-2019
  community_wards.csv         ward for each community
  census2021_all_communities.csv  2021 Census population and households, all communities
  rental_matches.json         every rental (multi-residential) property with the building permits matched to it
  communities_enriched.csv    311 counts, 2021 Census and area measures by community (main study)
  311_requests_by_community_service.csv   311 requests by community and type (main study)
  SOURCES.csv                 the City open data query behind each input
Data: City of Calgary Open Data, Open Government Licence - City of Calgary.
