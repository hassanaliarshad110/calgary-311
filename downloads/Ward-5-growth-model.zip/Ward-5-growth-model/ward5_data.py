"""Ward 5 results for the add-on page and PDF (reads growth_results.csv from growth_model.py)."""
import os, json
import numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__)) + '/'
def find(name, *alts):
    for n in (name,) + alts:
        if os.path.exists(HERE + n): return HERE + n
    raise FileNotFoundError(name)
G = pd.read_csv(HERE + 'growth_results.csv'); G['ward'] = G.ward.astype(str)
K = pd.read_csv(find('communities_enriched.csv', '../communities_enriched.csv'))
G = G.merge(K[['comm', 'infra_defect', 'app_share', 'close7_pct', 'App', 'closed_n', 'w7', 'new_units', 'income', 'newcomer', 'renter', 'res_parcels']], on='comm')
S = json.load(open(HERE + 'growth_summary.json'))
svc = pd.read_csv(find('311_requests_by_community_service.csv', '../pkg/Calgary-311-Study/01_Source_Data/311_requests_by_community_service.csv'))

def pooled(d):
    u = d[d.expected_corr.notna()]
    return dict(pop21=int(d['pop'].sum()), pop=int(d.pop_mid.sum()), pop_lo=int(d.pop_mid_low.sum()), pop_hi=int(d.pop_mid_high.sum()),
                infra=int(d.infra.sum()), req=int(d.all_req.sum()),
                rate=round(u.infra.sum() / u.pop_mid.sum() * 500, 1), rate21=round(u.infra.sum() / u['pop'].sum() * 500, 1),
                expected=round(float((u.expected_corr * u.pop_mid).sum() / u.pop_mid.sum()), 1),
                gap=round(float((u.infra.sum() / (u.expected_corr * u.pop_mid / 500).sum() - 1) * 100), 1),
                all_rate=round(d.all_req.sum() / d.pop_mid.sum() * 500, 1), app=round(d.App.sum() / d.all_req.sum() * 100, 1),
                close7=round(d.w7.sum() / d.closed_n.sum() * 100, 1), defect=round(u.infra_defect.sum() / u.pop_mid.sum() * 500, 1))
WARDS = {w: pooled(d) for w, d in G.groupby('ward') if w != 'nan'}
for key in ['rate', 'gap']:
    for i, w in enumerate(sorted(WARDS, key=lambda w: WARDS[w][key])): WARDS[w]['rk_' + key] = i + 1
CITY = pooled(G)
w5 = G[G.ward == '5'].copy()
comms = []
for _, r in w5.sort_values('name').iterrows():
    top = svc[svc.community_code == r.comm].sort_values('requests', ascending=False).head(5)
    comms.append(dict(c=r.comm, n=r['name'], flag=bool(r.hgrowth >= 1.5), hgrowth=round(float(r.hgrowth), 3), homes_mid=int(r.homes_mid), pop21=int(r['pop']), hh21=int(r.total_private_households), homes21=int(r.homes_census),
        homes25=int(r.homes_end2025), lots=int(r.noyear), ppl=round(float(r.k), 2), pop=int(r.pop_mid), pop_lo=int(r.pop_mid_low), pop_hi=int(r.pop_mid_high),
        growth=round(float(r.pop_mid / r['pop']), 2), infra=int(r.infra), defect=int(r.infra_defect),
        rate21=round(float(r.infra_rate), 1), rate=round(float(r.infra_rate_corr), 1), rate_lo=round(float(r.infra_rate_corr_lo), 1), rate_hi=round(float(r.infra_rate_corr_hi), 1),
        gap21=None if pd.isna(r.report_gap_pct) else round(float(r.report_gap_pct), 1), expected=round(float(r.expected_corr), 1), gap=round(float(r.gap_corr), 1),
        defect_rate=round(float(r.infra_defect / r.pop_mid * 500), 1), noeng=round(float(r.noeng), 1), app=round(float(r.app_share), 1), close7=round(float(r.close7_pct), 1),
        units=int(r.new_units), svc={t.service_name: int(t.requests) for t in svc[svc.community_code == r.comm].itertuples()}, top=[[t.service_name.split(' - ', 1)[1], int(t.requests)] for t in top.itertuples()]))
check = pd.read_csv(HERE + 'growth_check_2016_2019.csv')
OUT = dict(summary=S, ward=WARDS['5'], city=CITY, wards=WARDS, comms=comms, councillor='Raj Dhaliwal',
           check_rows=check[check.growth > 1.2].round(1).to_dict('records'))
json.dump(OUT, open(HERE + 'ward5.json', 'w'), indent=1)
print(json.dumps(OUT['ward'], indent=0)); print('city', CITY)
print({w: (v['rate'], v['gap'], v['rk_gap']) for w, v in sorted(WARDS.items(), key=lambda x: int(x[0]))})
