"""Sensitivity check: add births and deaths since the 2021 Census to the growth-adjusted population.
City of Calgary (Economic Outlook, Spring 2026, Table 4): births 16,200 and deaths 8,700 (2024); 17,000 and 8,600 (2025).
Assumed for every year from Census day to the middle of the study (May 2021 - Oct 2025, 4.4 years): 16,500 births and
8,650 deaths a year. Births are shared out by each community's number of children (0-14), deaths by its seniors
(65+ weighted 25 times the rest, roughly the ratio of death rates)."""
import os, json, math
import numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__)) + '/'
G = pd.read_csv(HERE + 'growth_results.csv')
K = pd.read_csv(HERE + '../communities_enriched.csv') if os.path.exists(HERE + '../communities_enriched.csv') else pd.read_csv(HERE + 'communities_enriched.csv')
G = G.merge(K[['comm', 'kids_pct', 'seniors_pct', 'log_income', 'renter', 'dist_km', 'age_yrs', 'pre1970', 'csa']], on='comm')
YEARS, BIRTHS, DEATHS = 4.4, 16500, 8650
share = G['pop'] / G['pop'].sum()                                     # study communities' share of the city
wb = G['pop'] * G.kids_pct.fillna(G.kids_pct.mean()); wd = G['pop'] * (G.seniors_pct.fillna(G.seniors_pct.mean()) * 25 + (100 - G.seniors_pct.fillna(G.seniors_pct.mean())))
G['births'] = YEARS * BIRTHS * G['pop'].sum() / 1289690 * wb / wb.sum()
G['deaths'] = YEARS * DEATHS * G['pop'].sum() / 1289690 * wd / wd.sum()
G['pop_nat'] = G.pop_mid + G.births - G.deaths
G['rate_nat'] = G.infra / G.pop_nat * 500
def wls(df, y, xs, w):
    df = df.dropna(subset=[y] + xs + [w]); Xm = np.column_stack([np.ones(len(df))] + [df[x].values for x in xs]); ww = np.sqrt(df[w].values)
    return np.linalg.lstsq(Xm * ww[:, None], np.log(df[y].values + 1) * ww, rcond=None)[0]
XS = ['log_income', 'renter', 'noeng', 'dist_km', 'age_yrs', 'pre1970']

eff = lambda b: (math.exp(b * 4) - 1) * 100
b = wls(G, 'rate_nat', XS, 'pop_nat'); b0 = wls(G, 'infra_rate_corr', XS, 'pop_mid')
w5 = G[G.ward.astype(str) == '5']
out = dict(effect_growth_only=round(eff(b0[3]), 1), effect_with_births_deaths=round(eff(b[3]), 1),
           study_pop_growth_only=int(G.pop_mid.sum()), study_pop_with_births_deaths=int(G.pop_nat.sum()),
           ward5_growth_only=int(w5.pop_mid.sum()), ward5_with_births_deaths=int(w5.pop_nat.sum()))
json.dump(out, open(HERE + 'natural_change_check.json', 'w'), indent=1); print(out)
print(G.assign(chg=(G.births - G.deaths) / G.pop_mid * 100).sort_values('chg')[['name', 'seniors_pct', 'kids_pct', 'chg']].round(1).iloc[[0, 1, 2, -3, -2, -1]].to_string())
print(w5.assign(chg=(w5.births - w5.deaths) / w5.pop_mid * 100)[['name', 'chg']].round(1).to_string())
