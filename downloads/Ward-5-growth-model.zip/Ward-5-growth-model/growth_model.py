"""Growth correction for 'Who Calgary's 311 Hears'.

Problem: reporting rates divide 311 requests (Oct 2024 - Sep 2026) by 2021 Census population.
Communities that have grown a lot since 2021 therefore look like they report far more than they do.

Model: population follows the number of homes standing.
  1. Homes standing at the end of each year come from the 2026 property assessment roll:
     every residential property with a year of construction, counted cumulatively by that year.
     Empty lots have no year of construction, so they drop out.
     A home is counted as lived in LAG years after its recorded year of construction
     (homes are recorded from the year building starts). LAG = 1 year is a balance: in the 2016-2019 check,
     half a year gives a smaller average error and one year a smaller typical (median) error; one year also
     matches 2021 Census households most closely (see growth_check_2016_2019.csv). LAG of 0.5 and 1.5 years give the range.
  2. Each community's people-per-home is fixed at the 2021 Census:
     k = 2021 Census population / homes lived in on Census day (May 11, 2021).
  3. Population in any month = k x homes lived in that month (homes added evenly through each year).
  4. Study-period population = average over the 24 study months (Oct 2024 - Sep 2026).
Only properties coded as dwellings are counted: residential class, land with a building, and a
residential use code (R...). Parking stalls, storage units and empty lots are left out.

Inputs (same folder):
  homes_by_year_built.csv   comm_code, year_of_construction, count       (data.calgary.ca 4bsw-nn7w)
  civic_census.csv          comm_code, census_year, population           (data.calgary.ca jtpc-xgsh)
  communities_enriched.csv  output of reanalyze.py (311 counts, 2021 Census and area measures by community)
  community_wards.csv       community code -> ward (data.calgary.ca tz8z-hyaz, ward holding most of the community's area)
"""
import os, json, math
import numpy as np, pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__)) + '/'
def find(name, *alts):
    for n in (name,) + alts:
        if os.path.exists(HERE + n): return HERE + n
    raise FileNotFoundError(name)
K = pd.read_csv(find('communities_enriched.csv', '../communities_enriched.csv'))
WARD = dict(pd.read_csv(find('community_wards.csv')).astype(str).values)
K['ward'] = K.comm.map(WARD)

def col(df, *names):
    for n in names:
        for c in df.columns:
            if c.lower() == n: return c
    raise KeyError(names)

# ---------- homes standing by year ----------
hb = pd.read_csv(HERE + 'homes_by_year_built.csv')
hc, hy, hn = col(hb, 'comm_code'), col(hb, 'year_of_construction'), col(hb, 'count', 'count_1', 'count(*)')
hb = hb.rename(columns={hc: 'comm', hy: 'yr', hn: 'n'})
hb['yr'] = pd.to_numeric(hb.yr, errors='coerce'); hb['n'] = pd.to_numeric(hb.n)
NOYEAR = hb[hb.yr.isna()].groupby('comm').n.sum()            # properties with no build year (mostly empty lots)
hb = hb[hb.yr.notna() & (hb.yr <= 2026)]
Y = hb.pivot_table(index='comm', columns='yr', values='n', aggfunc='sum', fill_value=0)
Y.columns = Y.columns.astype(int)
for y in range(1900, 2027):
    if y not in Y.columns: Y[y] = 0
Y = Y[sorted(Y.columns)]
H_end = Y.cumsum(axis=1)                                       # homes standing at end of year

# ---------- rental buildings: the roll lists each as one property; use its real number of units ----------
# rental_units.csv (from rental_units.py): units per multi-residential property, from building permits where they
# match, otherwise estimated from assessed value. People per rental unit: A (central), range A_RANGE.
A, A_RANGE = 2.0, (1.5, 2.6)        # 1.5 = downtown apartment households; 2.6 = average Calgary household (2021 Census)
# a rental unit never holds more people than the community's average 2021 household
HH = dict(zip(K.comm, K.avg_household_size))
if os.path.exists(HERE + 'rental_units.csv'):
    ru = pd.read_csv(HERE + 'rental_units.csv'); ru = ru[ru.year_of_construction.notna() & (ru.year_of_construction <= 2026)]
    for c in set(ru.comm) - set(Y.index): Y.loc[c] = 0
    Y = Y.fillna(0); H_end = Y.cumsum(axis=1)
Yp = Y * 0
EV = pd.DataFrame(columns=['comm', 'code', 'units', 'kind', 't'])
if os.path.exists(HERE + 'rental_units.csv'):
    ru['yr'] = ru.year_of_construction.astype(int)
    for (c, y), d in ru.groupby(['comm', 'yr']):
        if c in Y.index and y in Y.columns:
            Yp.loc[c, y] += int(d.code.str.startswith('R').sum())   # R-coded rental properties are already counted once as homes
    EV = pd.read_csv(HERE + 'rental_movein.csv')
Yo = Y - Yp                                                      # homes other than rental buildings
Ho_end = Yo.cumsum(axis=1)
LAG = 1.0
def _at(M, Mend, comm, t):
    if comm not in Mend.index: return np.nan
    yr = int(math.floor(t)); f = t - yr
    if yr >= 2026: return Mend.loc[comm, 2025] + M.loc[comm, 2025] * (t - 2026)
    prev = Mend.loc[comm, yr - 1] if (yr - 1) in Mend.columns else 0
    return prev + M.loc[comm, yr] * f
EVC = {c: d for c, d in EV.groupby('comm')}
def _units(comm, t, lag, kinds):
    """Rental units lived in at time t: permit units from 6 months after completion; others spread over the year
    after year of construction + lag (as for all homes)."""
    d = EVC.get(comm)
    if d is None: return 0.0
    d = d[d.kind.isin(kinds)]
    fixed = d[d.kind == 'permit']; rest = d[d.kind != 'permit']
    u = fixed.units[fixed.t <= t].sum()
    if len(rest): u += (rest.units * ((t - (rest.t + lag)).clip(0, 1))).sum()
    return float(u)
# Estimated (no permit) units can be too high where assessed values include land or shops. On Census day the homes
# counted cannot exceed 2021 Census households by more than 5% (allowing for empty homes), so estimated units are
# scaled down where needed.
CENSUS = 2021 + (31 + 28 + 31 + 30 + 10) / 365                  # May 11, 2021
HHN = dict(zip(K.comm, K.total_private_households)); SCALE = {}
for c in EVC:
    ue = _units(c, CENSUS, LAG, ['estimated']); hh = HHN.get(c)
    if ue > 0 and hh == hh and hh:
        room = hh * 1.05 - (_at(Yo, Ho_end, c, CENSUS - LAG) if c in Ho_end.index else 0) - _units(c, CENSUS, LAG, ['permit', 'yoc'])
        SCALE[c] = float(min(1.0, max(room, 0) / ue))
def units_at(comm, t, lag=None):
    lag = LAG if lag is None else lag
    return _units(comm, t, lag, ['permit', 'yoc']) + SCALE.get(comm, 1.0) * _units(comm, t, lag, ['estimated'])

def homes_at(comm, t, pace2026=1.0):
    """Homes lived in at decimal year t, other than rental-building units (e.g. 2021.36 = May 11, 2021)."""
    return _at(Yo, Ho_end, comm, t)
def people(comm, pop0, t0, ts, lag, a):
    """Calibrate people per home at t0 to pop0, then estimate population at times ts."""
    ho0, u0 = homes_at(comm, t0 - lag), units_at(comm, t0, lag)
    if not ho0 or np.isnan(ho0) or ho0 < 20: return None, None
    hh = HH.get(comm); a = min(a, hh) if hh == hh and hh else a
    k = max((pop0 - a * u0) / ho0, 1.0)
    return k, np.mean([k * homes_at(comm, t - lag) + a * units_at(comm, t, lag) for t in ts])

CENSUS = 2021 + (31 + 28 + 31 + 30 + 10) / 365                  # May 11, 2021
MONTHS = [2024 + 9.5 / 12 + i / 12 for i in range(24)]         # mid-month, Oct 2024 ... Sep 2026

rows = []
for _, r in K.iterrows():
    k, pm = people(r.comm, r['pop'], CENSUS, MONTHS, LAG, A)
    if k is None:
        rows.append(dict(comm=r.comm, ok=False)); continue
    alt = [people(r.comm, r['pop'], CENSUS, MONTHS, L, a)[1] for L in (0.5, 1.0, 1.5) for a in A_RANGE + (A,)]
    hc21 = homes_at(r.comm, CENSUS - LAG) + units_at(r.comm, CENSUS)
    mid = np.mean([homes_at(r.comm, t - LAG) + units_at(r.comm, t) for t in MONTHS])
    # plausibility screen: homes counted on Census day should be close to 2021 Census households. Where they differ by
    # more than 15% (homes missing from the roll, e.g. mobile homes, or homes not yet lived in), people per home is not
    # reliable, so new homes get the community's 2021 average household size instead.
    hh, hs = r.total_private_households, r.avg_household_size
    ratio = hc21 / hh if hh == hh and hh else np.nan
    screen = bool(ratio == ratio and abs(ratio - 1) > 0.15)
    if screen:
        hs = hs if hs == hs and hs else 2.6
        lift = lambda L, a: r['pop'] + hs * (np.mean([homes_at(r.comm, t - L) + units_at(r.comm, t, L) for t in MONTHS]) - (homes_at(r.comm, CENSUS - L) + units_at(r.comm, CENSUS, L)))
        pm = max(lift(LAG, A), r['pop']); alt = [max(lift(L, A), r['pop']) for L in (0.5, 1.0, 1.5)]
    rows.append(dict(comm=r.comm, ok=True, screen=screen, census_ratio=round(ratio, 3) if ratio == ratio else None, homes_census=round(hc21), k=round(k, 3), homes_mid=round(mid),
                     rental_units_census=round(units_at(r.comm, CENSUS)), rental_units_mid=round(np.mean([units_at(r.comm, t) for t in MONTHS])),
                     homes_end2025=int(Ho_end.loc[r.comm, 2025] + units_at(r.comm, 2026.0)) if r.comm in Ho_end.index else None,
                     noyear=int(NOYEAR.get(r.comm, 0)),
                     pop_mid=round(pm), pop_mid_high=round(np.nanmax(alt)), pop_mid_low=round(np.nanmin(alt)), hgrowth=round(pm / r['pop'], 3)))
G = K.merge(pd.DataFrame(rows), on='comm', how='left')
for c_ in ['pop_mid', 'pop_mid_low', 'pop_mid_high']: G[c_] = G[c_].where(G.ok == True, G['pop'])
G['hgrowth'] = G.hgrowth.where(G.ok == True, 1.0)
G = G.copy()
G['infra_rate_corr'] = G.infra / G.pop_mid * 500
G['infra_rate_corr_hi'] = G.infra / G.pop_mid_low * 500       # fewer people -> higher rate
G['infra_rate_corr_lo'] = G.infra / G.pop_mid_high * 500
G['all_rate_corr'] = G.all_req / G.pop_mid * 500

# ---------- check against the City's own 2016 and 2019 counts ----------
CHECK = None
if os.path.exists(HERE + 'civic_census.csv'):
    cv = pd.read_csv(HERE + 'civic_census.csv')
    cv = cv.rename(columns={col(cv, 'comm_code'): 'comm', col(cv, 'census_year'): 'y', col(cv, 'population'): 'p'})
    cv = cv[~cv.comm.isin(set(cv[cv.duplicated(['comm', 'y'], keep=False)].comm))]   # communities split in 2018 have two rows
    cv['y'] = pd.to_numeric(cv.y); cv['p'] = pd.to_numeric(cv.p, errors='coerce')
    p16 = cv[cv.y == 2016].set_index('comm').p; p19 = cv[cv.y == 2019].set_index('comm').p
    APR = 3.0 / 12                                                # civic census day: April 1
    ch = []
    for c in sorted(set(p16.index) & set(p19.index) & set(H_end.index)):
        if p16[c] >= 500:
            k16, pr = people(c, p16[c], 2016 + APR, [2019 + APR], LAG, A)
            if k16 is not None:
                h16 = homes_at(c, 2016 + APR - LAG) + units_at(c, 2016 + APR); h19 = homes_at(c, 2019 + APR - LAG) + units_at(c, 2019 + APR)
                ch.append(dict(comm=c, p16=p16[c], p19=p19[c], growth=h19 / h16, pred=pr))
    CHECK = pd.DataFrame(ch); CHECK['err'] = (CHECK.pred / CHECK.p19 - 1) * 100
    CHECK['naive_err'] = (CHECK.p16 / CHECK.p19 - 1) * 100      # error if population is held at 2016

# ---------- refit the study's main model with corrected population ----------
def wls(df, y, xs, w):
    df = df.dropna(subset=[y] + xs + [w])
    Xm = np.column_stack([np.ones(len(df))] + [df[x].values for x in xs]); yy = np.log(df[y].values + 1); ww = np.sqrt(df[w].values)
    beta = np.linalg.lstsq(Xm * ww[:, None], yy * ww, rcond=None)[0]
    return dict(zip(['const'] + xs, beta)), df, Xm, beta
eff = lambda b: (math.exp(b * 4) - 1) * 100                      # 1% -> 5% with no English
XS = ['log_income', 'renter', 'noeng', 'dist_km', 'age_yrs', 'pre1970']
b0, *_ = wls(G, 'infra_rate', XS, 'pop')
b1, *_ = wls(G, 'infra_rate_corr', XS, 'pop_mid')
rng = np.random.default_rng(42); areas = G.csa.unique(); bs = []; IDX = {a: G.index[G.csa == a].values for a in areas}
for _ in range(1000):
    pick = rng.choice(areas, len(areas), replace=True)
    d = G.loc[np.concatenate([IDX[a] for a in pick])].reset_index(drop=True); bs.append(eff(wls(d, 'infra_rate_corr', XS, 'pop_mid')[0]['noeng']))
# expected rate without language, corrected population
XE = ['log_income', 'renter', 'dist_km', 'age_yrs', 'pre1970']
be, d, Xm, beta = wls(G, 'infra_rate_corr', XE, 'pop_mid')
ex = np.exp(Xm @ beta) - 1; smear = np.average(d.infra_rate_corr.values / ex, weights=d.pop_mid.values)
G.loc[d.index, 'expected_corr'] = ex * smear
G['gap_corr'] = (G.infra_rate_corr / G.expected_corr - 1) * 100
# language groups (same quarters as the study), corrected population
G['ne_q'] = pd.qcut(G.noeng.rank(method='first'), 4, labels=[1, 2, 3, 4]).astype(int)
NEQ = {int(q): dict(orig=round(d.infra.sum() / d['pop'].sum() * 500, 1), corr=round(d.infra.sum() / d.pop_mid.sum() * 500, 1)) for q, d in G.groupby('ne_q')}

OUT = dict(
    effect_orig=round(eff(b0['noeng']), 1), effect_corr=round(eff(b1['noeng']), 1),
    effect_corr_ci=[round(float(np.percentile(bs, 2.5)), 1), round(float(np.percentile(bs, 97.5)), 1)],
    rawgap_orig=round((1 - NEQ[4]['orig'] / NEQ[1]['orig']) * 100, 1), rawgap_corr=round((1 - NEQ[4]['corr'] / NEQ[1]['corr']) * 100, 1),
    neq=NEQ, pop_2021=int(G['pop'].sum()), pop_mid=int(G.pop_mid.sum()),
    check=None if CHECK is None else dict(n=len(CHECK), mape=round(CHECK.err.abs().mean(), 1), median=round(CHECK.err.abs().median(), 1),
        grow_n=int((CHECK.growth > 1.2).sum()), grow_mape=round(CHECK[CHECK.growth > 1.2].err.abs().mean(), 1),
        grow_naive=round(CHECK[CHECK.growth > 1.2].naive_err.abs().mean(), 1), grow_median=round(CHECK[CHECK.growth > 1.2].err.abs().median(), 1),
        grow_naive_median=round(CHECK[CHECK.growth > 1.2].naive_err.abs().median(), 1)),
)
# ---------- whole city and wards: every community, including those outside the study ----------
CENS = pd.read_csv(find('census2021_all_communities.csv'))
for c_ in ['pop2021', 'households2021', 'avg_household_size']: CENS[c_] = pd.to_numeric(CENS[c_], errors='coerce')
for _, r in CENS.iterrows():
    if r.comm not in HH and r.avg_household_size == r.avg_household_size: HH[r.comm] = r.avg_household_size
allc = sorted(set(Ho_end.index) | set(EVC) | set(CENS.comm)); P21 = dict(zip(CENS.comm, CENS.pop2021.fillna(0)))
done, newc = {}, []
for c in allc:
    p0 = P21.get(c, 0) or 0
    k_, pm_ = people(c, p0, CENSUS, MONTHS, LAG, A) if p0 > 0 else (None, None)
    if k_ is not None: done[c] = pm_
    else: newc.append(c)
# study communities keep the study estimate (including the plausibility screen), so ward and city totals match the study
for c, v in zip(G.comm, G.pop_mid):
    if c in done and v == v: done[c] = float(v)
okc = [c for c in done if (P21.get(c) or 0) > 0]
KCITY = sum(P21[c] - A * units_at(c, CENSUS) for c in okc) / sum(homes_at(c, CENSUS - LAG) for c in okc)
for c in newc:      # new communities and those with too few homes on Census day: city-wide people per home
    ho = np.mean([homes_at(c, t - LAG) if c in Ho_end.index else 0 for t in MONTHS]); u = np.mean([units_at(c, t) for t in MONTHS])
    p0 = P21.get(c, 0) or 0
    done[c] = max(p0, KCITY * ho + A * u)
CITY = pd.DataFrame({'comm': list(done), 'pop_mid': list(done.values())}); CITY['pop2021'] = CITY.comm.map(P21).fillna(0); CITY['ward'] = CITY.comm.map(WARD)
WT = CITY.groupby('ward')[['pop_mid', 'pop2021']].sum().round()
EVp = EV[EV.kind.isin(['permit', 'yoc'])]; EVe = EV[EV.kind == 'estimated']
OUT['rental'] = dict(permit_props=int(EVp.roll.nunique()) if 'roll' in EV else None, permit_units=int(EVp.units.sum()),
                     est_props=int(EVe.roll.nunique()) if 'roll' in EV else None, est_units=int(EVe.units.sum()),
                     est_units_used=int(round(sum(SCALE.get(c, 1.0) * d.units.sum() for c, d in EVe.groupby('comm')))))
OUT['screened'] = sorted(G[G.screen == True].name.tolist())
OUT['n_fit'] = int(G.dropna(subset=XS + ['infra_rate_corr']).shape[0])
OUT['city_total'] = int(CITY.pop_mid.sum()); OUT['city_2021'] = int(CITY.pop2021.sum()); OUT['city_people_per_home'] = round(KCITY, 2)
OUT['wards_total'] = {w: dict(pop=int(v.pop_mid), pop2021=int(v.pop2021)) for w, v in WT.iterrows()}
CITY.round().to_csv(HERE + 'population_all_communities.csv', index=False)
keep = ['comm', 'name', 'ward', 'pop', 'total_private_households', 'screen', 'census_ratio', 'homes_census', 'rental_units_census', 'rental_units_mid', 'k', 'homes_end2025', 'noyear', 'homes_mid', 'pop_mid', 'pop_mid_low', 'pop_mid_high', 'hgrowth',
        'infra', 'all_req', 'infra_rate', 'infra_rate_corr', 'infra_rate_corr_lo', 'infra_rate_corr_hi', 'all_rate_corr', 'expected_rate', 'report_gap_pct', 'expected_corr', 'gap_corr', 'noeng', 'homes_vs_2021']
G[keep].round(3).to_csv(HERE + 'growth_results.csv', index=False)
G[G.homes_vs_2021.gt(1.5) & G.ok.eq(True)][['comm', 'pop_mid']].to_csv(HERE + 'growth_pop_flagged.csv', index=False)
if CHECK is not None: CHECK.round(2).to_csv(HERE + 'growth_check_2016_2019.csv', index=False)
json.dump(OUT, open(HERE + 'growth_summary.json', 'w'), indent=1)
print(json.dumps(OUT, indent=1))
print(G[G.ward == '5'][['name', 'pop', 'pop_mid', 'hgrowth', 'infra_rate', 'infra_rate_corr', 'report_gap_pct', 'gap_corr']].round(1).to_string())
