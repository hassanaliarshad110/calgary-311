"""Growth correction for 'Who Calgary's 311 Hears'.

Problem: reporting rates divide 311 requests (Oct 2024 - Sep 2026) by 2021 Census population.
Communities that have grown a lot since 2021 therefore look like they report far more than they do.

Model: population follows the number of homes standing.
  1. Homes standing at the end of each year come from the 2026 property assessment roll:
     every residential property with a year of construction, counted cumulatively by that year.
     Empty lots have no year of construction, so they drop out.
     A home is counted as lived in LAG years after its recorded year of construction
     (homes are recorded from the year building starts). LAG = 1 year fits best: it best predicts
     the City's 2019 civic census from its 2016 count, and it matches 2021 Census households in
     fast-growing communities (see growth_check_2016_2019.csv). LAG of 0.5 and 1.5 years give the range.
  2. Each community's people-per-home is fixed at the 2021 Census:
     k = 2021 Census population / homes lived in on Census day (May 11, 2021).
  3. Population in any month = k x homes lived in that month (homes added evenly through each year).
  4. Study-period population = average over the 24 study months (Oct 2024 - Sep 2026).
Only properties coded as dwellings are counted: residential class, land with a building, and a
residential use code (R...). Parking stalls, storage units and empty lots are left out.

Inputs (same folder):
  homes_by_year_built.csv   comm_code, year_of_construction, count       (data.calgary.ca 4bsw-nn7w)
  civic_census.csv          comm_code, census_year, population           (data.calgary.ca jtpc-xgsh)
  communities_enriched.csv  output of reanalyze.py (311 counts, 2021 Census and area measures by community)
  community_wards.csv       community code -> ward (data.calgary.ca tz8z-hyaz, ward holding most of the community's area)
"""
import os, json, math
import numpy as np, pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__)) + '/'
def find(name, *alts):
    for n in (name,) + alts:
        if os.path.exists(HERE + n): return HERE + n
    raise FileNotFoundError(name)
K = pd.read_csv(find('communities_enriched.csv', '../communities_enriched.csv'))
WARD = dict(pd.read_csv(find('community_wards.csv')).astype(str).values)
K['ward'] = K.comm.map(WARD)

def col(df, *names):
    for n in names:
        for c in df.columns:
            if c.lower() == n: return c
    raise KeyError(names)

# ---------- homes standing by year ----------
hb = pd.read_csv(HERE + 'homes_by_year_built.csv')
hc, hy, hn = col(hb, 'comm_code'), col(hb, 'year_of_construction'), col(hb, 'count', 'count_1', 'count(*)')
hb = hb.rename(columns={hc: 'comm', hy: 'yr', hn: 'n'})
hb['yr'] = pd.to_numeric(hb.yr, errors='coerce'); hb['n'] = pd.to_numeric(hb.n)
NOYEAR = hb[hb.yr.isna()].groupby('comm').n.sum()            # properties with no build year (mostly empty lots)
hb = hb[hb.yr.notna() & (hb.yr <= 2026)]
Y = hb.pivot_table(index='comm', columns='yr', values='n', aggfunc='sum', fill_value=0)
Y.columns = Y.columns.astype(int)
for y in range(1900, 2027):
    if y not in Y.columns: Y[y] = 0
Y = Y[sorted(Y.columns)]
H_end = Y.cumsum(axis=1)                                       # homes standing at end of year

LAG = 1.0
def homes_at(comm, t, pace2026=1.0):
    """Homes standing at decimal year t (e.g. 2021.36 = May 11, 2021)."""
    if comm not in H_end.index: return np.nan
    yr = int(math.floor(t)); f = t - yr
    prev = H_end.loc[comm, yr - 1] if (yr - 1) in H_end.columns else 0
    add = Y.loc[comm, yr] if yr <= 2025 else Y.loc[comm, 2025] * pace2026
    if yr >= 2026: prev = H_end.loc[comm, 2025] + Y.loc[comm, 2025] * pace2026 * (yr - 2026)
    return prev + add * f

CENSUS = 2021 + (31 + 28 + 31 + 30 + 10) / 365                  # May 11, 2021
MONTHS = [2024 + 9.5 / 12 + i / 12 for i in range(24)]         # mid-month, Oct 2024 ... Sep 2026

rows = []
for _, r in K.iterrows():
    hc21 = homes_at(r.comm, CENSUS - LAG)
    if not hc21 or np.isnan(hc21) or hc21 < 20:
        rows.append(dict(comm=r.comm, ok=False)); continue
    k = r['pop'] / hc21
    mid = np.mean([homes_at(r.comm, t - LAG) for t in MONTHS])
    lo_ = [r['pop'] / homes_at(r.comm, CENSUS - L) * np.mean([homes_at(r.comm, t - L) for t in MONTHS]) if homes_at(r.comm, CENSUS - L) >= 20 else np.nan for L in (0.5, 1.5)]
    rows.append(dict(comm=r.comm, ok=True, homes_census=round(hc21), k=round(k, 3), homes_mid=round(mid),
                     homes_end2025=int(H_end.loc[r.comm, 2025]), noyear=int(NOYEAR.get(r.comm, 0)),
                     pop_mid=round(k * mid), pop_mid_high=round(np.nanmax(lo_ + [k * mid])), pop_mid_low=round(np.nanmin(lo_ + [k * mid])), hgrowth=round(mid / hc21, 3)))
G = K.merge(pd.DataFrame(rows), on='comm', how='left')
for c_ in ['pop_mid', 'pop_mid_low', 'pop_mid_high']: G[c_] = G[c_].where(G.ok == True, G['pop'])
G['hgrowth'] = G.hgrowth.where(G.ok == True, 1.0)
G = G.copy()
G['infra_rate_corr'] = G.infra / G.pop_mid * 500
G['infra_rate_corr_hi'] = G.infra / G.pop_mid_low * 500       # fewer people -> higher rate
G['infra_rate_corr_lo'] = G.infra / G.pop_mid_high * 500
G['all_rate_corr'] = G.all_req / G.pop_mid * 500

# ---------- check against the City's own 2016 and 2019 counts ----------
CHECK = None
if os.path.exists(HERE + 'civic_census.csv'):
    cv = pd.read_csv(HERE + 'civic_census.csv')
    cv = cv.rename(columns={col(cv, 'comm_code'): 'comm', col(cv, 'census_year'): 'y', col(cv, 'population'): 'p'})
    cv = cv[~cv.comm.isin(set(cv[cv.duplicated(['comm', 'y'], keep=False)].comm))]   # communities split in 2018 have two rows
    cv['y'] = pd.to_numeric(cv.y); cv['p'] = pd.to_numeric(cv.p, errors='coerce')
    p16 = cv[cv.y == 2016].set_index('comm').p; p19 = cv[cv.y == 2019].set_index('comm').p
    APR = 3.0 / 12                                                # civic census day: April 1
    ch = []
    for c in sorted(set(p16.index) & set(p19.index) & set(H_end.index)):
        if p16[c] >= 500:
            h16, h19 = homes_at(c, 2016 + APR - LAG), homes_at(c, 2019 + APR - LAG)
            if h16 >= 20:
                ch.append(dict(comm=c, p16=p16[c], p19=p19[c], growth=h19 / h16, pred=p16[c] * h19 / h16))
    CHECK = pd.DataFrame(ch); CHECK['err'] = (CHECK.pred / CHECK.p19 - 1) * 100
    CHECK['naive_err'] = (CHECK.p16 / CHECK.p19 - 1) * 100      # error if population is held at 2016

# ---------- refit the study's main model with corrected population ----------
def wls(df, y, xs, w):
    df = df.dropna(subset=[y] + xs + [w])
    Xm = np.column_stack([np.ones(len(df))] + [df[x].values for x in xs]); yy = np.log(df[y].values + 1); ww = np.sqrt(df[w].values)
    beta = np.linalg.lstsq(Xm * ww[:, None], yy * ww, rcond=None)[0]
    return dict(zip(['const'] + xs, beta)), df, Xm, beta
eff = lambda b: (math.exp(b * 4) - 1) * 100                      # 1% -> 5% with no English
XS = ['log_income', 'renter', 'noeng', 'dist_km', 'age_yrs', 'pre1970']
b0, *_ = wls(G, 'infra_rate', XS, 'pop')
b1, *_ = wls(G, 'infra_rate_corr', XS, 'pop_mid')
rng = np.random.default_rng(42); areas = G.csa.unique(); bs = []; IDX = {a: G.index[G.csa == a].values for a in areas}
for _ in range(1000):
    pick = rng.choice(areas, len(areas), replace=True)
    d = G.loc[np.concatenate([IDX[a] for a in pick])].reset_index(drop=True); bs.append(eff(wls(d, 'infra_rate_corr', XS, 'pop_mid')[0]['noeng']))
# expected rate without language, corrected population
XE = ['log_income', 'renter', 'dist_km', 'age_yrs', 'pre1970']
be, d, Xm, beta = wls(G, 'infra_rate_corr', XE, 'pop_mid')
ex = np.exp(Xm @ beta) - 1; smear = np.average(d.infra_rate_corr.values / ex, weights=d.pop_mid.values)
G.loc[d.index, 'expected_corr'] = ex * smear
G['gap_corr'] = (G.infra_rate_corr / G.expected_corr - 1) * 100
# language groups (same quarters as the study), corrected population
G['ne_q'] = pd.qcut(G.noeng.rank(method='first'), 4, labels=[1, 2, 3, 4]).astype(int)
NEQ = {int(q): dict(orig=round(d.infra.sum() / d['pop'].sum() * 500, 1), corr=round(d.infra.sum() / d.pop_mid.sum() * 500, 1)) for q, d in G.groupby('ne_q')}

OUT = dict(
    effect_orig=round(eff(b0['noeng']), 1), effect_corr=round(eff(b1['noeng']), 1),
    effect_corr_ci=[round(float(np.percentile(bs, 2.5)), 1), round(float(np.percentile(bs, 97.5)), 1)],
    rawgap_orig=round((1 - NEQ[4]['orig'] / NEQ[1]['orig']) * 100, 1), rawgap_corr=round((1 - NEQ[4]['corr'] / NEQ[1]['corr']) * 100, 1),
    neq=NEQ, pop_2021=int(G['pop'].sum()), pop_mid=int(G.pop_mid.sum()),
    check=None if CHECK is None else dict(n=len(CHECK), mape=round(CHECK.err.abs().mean(), 1), median=round(CHECK.err.abs().median(), 1),
        grow_n=int((CHECK.growth > 1.2).sum()), grow_mape=round(CHECK[CHECK.growth > 1.2].err.abs().mean(), 1),
        grow_naive=round(CHECK[CHECK.growth > 1.2].naive_err.abs().mean(), 1), grow_median=round(CHECK[CHECK.growth > 1.2].err.abs().median(), 1),
        grow_naive_median=round(CHECK[CHECK.growth > 1.2].naive_err.abs().median(), 1)),
)
keep = ['comm', 'name', 'ward', 'pop', 'total_private_households', 'homes_census', 'k', 'homes_end2025', 'noyear', 'homes_mid', 'pop_mid', 'pop_mid_low', 'pop_mid_high', 'hgrowth',
        'infra', 'all_req', 'infra_rate', 'infra_rate_corr', 'infra_rate_corr_lo', 'infra_rate_corr_hi', 'all_rate_corr', 'expected_rate', 'report_gap_pct', 'expected_corr', 'gap_corr', 'noeng', 'homes_vs_2021']
G[keep].round(3).to_csv(HERE + 'growth_results.csv', index=False)
G[G.homes_vs_2021.gt(1.5) & G.ok.eq(True)][['comm', 'pop_mid']].to_csv(HERE + 'growth_pop_flagged.csv', index=False)
if CHECK is not None: CHECK.round(2).to_csv(HERE + 'growth_check_2016_2019.csv', index=False)
json.dump(OUT, open(HERE + 'growth_summary.json', 'w'), indent=1)
print(json.dumps(OUT, indent=1))
print(G[G.ward == '5'][['name', 'pop', 'pop_mid', 'hgrowth', 'infra_rate', 'infra_rate_corr', 'report_gap_pct', 'gap_corr']].round(1).to_string())
