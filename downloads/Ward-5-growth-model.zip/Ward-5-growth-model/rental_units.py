"""Unit counts for rental (multi-residential) properties, which the assessment roll lists as one property each.
Input: rental_matches.json - every multi-residential property on the 2026 roll (use codes R510-R830) with the
new-building permits (2+ housing units, 1999 onward) whose address or location falls on it.
Output: rental_units.csv - comm, year_of_construction, units, source (permit / estimated);
rental_movein.csv - when each group of units is lived in (permit completion + 6 months, otherwise year of construction + 1)."""
import json, os
import numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__)) + '/'
rows = json.load(open(HERE + 'rental_matches.json'))
seen = set(); rows = [r for r in rows if not (r[0] in seen or seen.add(r[0]))]   # one row per roll number (the roll lists some properties twice)
BAD = {'Refused', 'Expired', 'File Closed', 'Suspended-Expired'}
# each permit goes to one property only: prefer a location match, then the higher-value property
cand = {}
for i, r in enumerate(rows):
    for p in r[7]:
        if p[3] in BAD: continue
        cand.setdefault(p[0], []).append((0 if p[6] == 'geo' else 1, -r[5], i, p[1]))
units, events = {}, {}
PD = {p[0]: p for r in rows for p in r[7]}
for pn, lst in cand.items():
    _, _, i, u = sorted(lst)[0]; units[i] = units.get(i, 0) + u
    done = PD[pn][5]                                              # permit completed date (blank if not completed)
    events.setdefault(i, []).append((u, done))
out = []
for i, r in enumerate(rows):
    yoc = float(r[4]) if r[4] else None
    out.append(dict(roll=r[0], address=r[1], comm=r[2], code=r[3], year_of_construction=yoc, value=r[5], units=units.get(i, 0)))
D = pd.DataFrame(out)
m = D[D.units > 0].copy(); m['vpu'] = m.value / m.units
m = m[(m.vpu > 80_000) & (m.vpu < 900_000)]                    # drop implausible matches when estimating value per unit
VPU = m.groupby('code').vpu.median(); ALL = m.vpu.median()
D['source'] = np.where(D.units > 0, 'permit', 'estimated')
est = (D.value / D.code.map(lambda c: VPU.get(c, ALL) if (m.code == c).sum() >= 5 else ALL)).round()
D.loc[D.units == 0, 'units'] = est[D.units == 0].clip(lower=2)
D['units'] = D.units.astype(int)
D.to_csv(HERE + 'rental_units.csv', index=False)
# move-in events: permit units become lived in 6 months after the permit is completed; other units a year after
# the roll's year of construction (as for all homes)
import datetime as dt
def dec(d):
    y, m, dd = map(int, d.split('-')); return y + (dt.date(y, m, dd) - dt.date(y, 1, 1)).days / 365.25
ev = []
for i, r in D.iterrows():
    for u, done in events.get(i, []):
        if done: ev.append(dict(roll=r.roll, comm=r.comm, code=r.code, units=u, kind='permit', t=round(dec(done) + 0.5, 3)))
        elif r.year_of_construction == r.year_of_construction: ev.append(dict(roll=r.roll, comm=r.comm, code=r.code, units=u, kind='yoc', t=r.year_of_construction))
    if r.source == 'estimated' and r.year_of_construction == r.year_of_construction:
        ev.append(dict(roll=r.roll, comm=r.comm, code=r.code, units=r.units, kind='estimated', t=r.year_of_construction))
pd.DataFrame(ev).to_csv(HERE + 'rental_movein.csv', index=False)
E = pd.DataFrame(ev); print(E.groupby('kind').units.sum().to_dict())
print(D.groupby('source').agg(properties=('roll', 'size'), units=('units', 'sum')))
print('value per unit used:', {k: round(v) for k, v in VPU.items()}, 'all', round(ALL))
