WHO CALGARY'S 311 HEARS - the study step by step in Python
Independent study by Hassan Ali. Not affiliated with The City of Calgary.
https://hassanaliarshad110.github.io/calgary-311/

The same code in two forms. Both download 8 data sets from City of Calgary Open Data (about 1 minute) and
work out every main result of the study in 12 numbered steps, each printed next to the published figure.

who_calgarys_311_hears.py
    One Python script.
    Run it whole:   install Python 3 from python.org (Windows: tick "Add Python to PATH"), then double-click
                    the file, or in a terminal in this folder:
                        py who_calgarys_311_hears.py          (Windows)
                        python3 who_calgarys_311_hears.py     (Mac / Linux)
                    It installs pandas and numpy the first time if they are missing.
    Block by block: open it in VS Code (with the Python extension) or Spyder. Each step starts with "# %%";
                    click "Run Cell" above a block to run just that step, in order from the top.

who_calgarys_311_hears_step_by_step.ipynb
    The same blocks as a notebook, with a plain-language note before each one.
    Google Colab (nothing to install): colab.research.google.com > File > Upload notebook, then Runtime > Run all.
    Jupyter or VS Code: open the file and run the cells from top to bottom.

The 12 steps
    1  Which communities are in the study (195 communities, 1,279,690 residents)
    2  Infrastructure reports per 1,000 residents a year
    3  Four groups by share of residents who can't speak English: the raw gap (39.3% fewer)
    4  Communities first settled 1975-2000 only (25.2% fewer)
    5  Income and language side by side
    6  The fair-comparison model (about 23% fewer for 5% vs 1% who can't speak English)
    7  1,000 bootstrap re-runs (95% range 9% to 33%)
    8  Every request type (lower in 20 of 21)
    9  Closing speed compared with the citywide pace (every group within 1.5%)
    10 Requests made through the 311 app
    11 Ward 5 communities against similar communities
    12 What the results show, and what they don't

Open Data is live: requests are closed, re-coded or merged as duplicates after the fact, so a few counts can
differ slightly from the published ones (downloaded October 20-21, 2026). The findings do not change.
Downloads are saved in a folder called api_responses next to the files; delete it to download again.

The full study package (all 14 model versions, every source extract and map data) is on the Method & data page.
Data: City of Calgary Open Data, Open Government Licence - City of Calgary.
