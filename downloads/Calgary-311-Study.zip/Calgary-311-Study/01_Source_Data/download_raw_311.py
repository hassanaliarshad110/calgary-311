"""Download the raw 311 records used in this study (about 1 million rows, ~250 MB).
Run on a computer with normal internet access:  python download_raw_311.py
Source: City of Calgary Open Data, 311 Service Requests (iahh-g8bj), Open Government Licence - City of Calgary."""
import urllib.request, urllib.parse, os
WHERE = "requested_date>='2024-10-01' AND requested_date<'2026-10-01'"
out = "311_raw_requests_oct2024_sep2026.csv"
page, offset, first = 200000, 0, True
with open(out, "w", encoding="utf-8", newline="") as f:
    while True:
        q = urllib.parse.urlencode({"$where": WHERE, "$order": "service_request_id", "$limit": page, "$offset": offset})
        with urllib.request.urlopen("https://data.calgary.ca/resource/iahh-g8bj.csv?" + q, timeout=300) as r:
            lines = r.read().decode("utf-8").splitlines(True)
        if not first: lines = lines[1:]
        f.writelines(lines); first = False
        print("rows so far:", offset + len(lines))
        if len(lines) < page: break
        offset += page
print("Saved", out, round(os.path.getsize(out)/1e6, 1), "MB")
