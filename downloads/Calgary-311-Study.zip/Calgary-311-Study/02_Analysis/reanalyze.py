import json, math, re
import numpy as np, pandas as pd
pd.set_option('display.width', 220)
import os
D = os.path.dirname(os.path.abspath(__file__)) + '/'   # run from 02_Analysis; reads raw/ here
S = ["Roads - Pothole Maintenance","Roads - Streetlight Maintenance","Roads - Traffic or Pedestrian Light Repair","Roads - Sidewalk - Curb and Gutter Repair","Roads - Roadway Maintenance","Roads - Backlane Maintenance","Roads - Debris on Street/Sidewalk/Boulevard","Roads - Signs - Missing - Damaged","Roads - Snow and Ice Control","Roads - Dead Animal Pick-Up","Roads - Pathway Concerns","Roads - Pathway Snow and Ice Concerns","WATS - Catch Basin Concerns","WATS - Sewage Back-up","WATS - Sewer Maintenance","WATS - Water Main Break or Leak","WATS - Service and Main Valve Issues","Parks - Tree Concern - GIS","Parks - Garbage - GIS","Parks - Maintenance - GIS","Parks - Infrastructure - GIS","Corporate - Graffiti Concerns","Corporate - Encampment Concerns","Bylaw - Snow and Ice on Sidewalk","Bylaw - Long Grass - Weeds Infraction","Bylaw - Material on Public Property","WRS - Cart Management","WRS - Waste - Residential","WRS - Recycling - Blue Cart","WRS - Compost - Green Cart"]
CAT = {'Roads':'Roads','WATS':'Water & sewer','Parks':'Parks & trees','Corporate':'Graffiti & encampments','Bylaw':'Bylaw','WRS':'Waste carts'}
A = pd.DataFrame(json.load(open(D+'raw/A.json')), columns=['comm','s','y','n','med','avg','w7','w30','o90']); A['service'] = A.s.map(lambda i: S[i]); A['cat'] = A.service.str.split(' - ').str[0].map(CAT)
B = json.load(open(D+'raw/B.json')); C = json.load(open(D+'raw/C.json')); X = json.load(open(D+'raw/X.json'))
age = {a.split()[0]: int(a.split()[1]) for a in open(D+'raw/age.txt').read().strip().split(',')}
R = {}  # results for PDF
import string
def nice(n):
    t = string.capwords(n.lower(), ' ')
    t = '/'.join(w[:1].upper()+w[1:] for w in t.split('/'))
    t = re.sub(r'\bMc([a-z])', lambda m: 'Mc'+m.group(1).upper(), t)
    t = re.sub(r'\bMacewan', 'MacEwan', t)
    return t

# ---------- community base table ----------
pop = {p[0]: p[2] for p in C['pop'] if p[2] is not None}
rows = []
R['no_area_500'] = [(nice(C['comms'][c]['name']), pop[c]) for c in C['comms'] if c in pop and pop[c] >= 500 and not C['map'].get(c)]
for c, info in C['comms'].items():
    csa = C['map'].get(c)
    if not csa or c not in pop: continue
    ind = C['ind'][csa]; lat, lon = info['lat'], info['lon']
    rows.append(dict(comm=c, name=nice(info['name']), pop=pop[c], csa=csa, lat=lat, lon=lon,
        dist_km=math.hypot((lat-51.0447)*111, (lon+114.0719)*111*math.cos(math.radians(51))),
        quadrant=csa.split('.')[-1], income=ind.get('Median Income'), lim_1864=ind.get('LIM-AT 18-64 years'), lim_017=ind.get('LIM-AT 0-17 years'), lim_65=ind.get('LIM-AT 65+ years'),
        noeng=ind.get('No English Knowledge'), newcomer=ind.get('Newcomers'), vismin=ind.get('Visible Minority'), indigenous=ind.get('Indigenous'),
        renter=ind.get('Renter'), lone_parent=ind.get('Lone Parent'), moved=ind.get('Moved in the last year'), detached=ind.get('Live in single detached home'),
        transit_work=ind.get('Transit to work'), drive_work=ind.get('Drive to work')))
K = pd.DataFrame(rows)
# census community-level extras
pa = pd.DataFrame(X['popage']).rename(columns={'community_code':'comm'})
for col in ['pop_age_0_to_14_percent','pop_age_65_to_84_percent','pop_age_85_and_over_percent']: pa[col] = pd.to_numeric(pa[col])
pa['kids_pct'] = pa.pop_age_0_to_14_percent; pa['seniors_pct'] = pa.pop_age_65_to_84_percent + pa.pop_age_85_and_over_percent
fam = pd.DataFrame(X['fam']).rename(columns={'community_code':'comm'})
for col in fam.columns[1:]: fam[col] = pd.to_numeric(fam[col])
emp = pd.DataFrame(X['emp']).rename(columns={'community_code':'comm'})
for col in ['labour_participation_rate','unemployment_rate_per','employment_rate_per']: emp[col] = pd.to_numeric(emp[col])
K = K.merge(pa[['comm','kids_pct','seniors_pct']], on='comm', how='left').merge(fam[['comm','total_private_households','avg_household_size','house_size_1_percent','one_parent_families_per']], on='comm', how='left').merge(emp[['comm','labour_participation_rate','unemployment_rate_per','top_1_industry','top_1_occupation']], on='comm', how='left')
asx = pd.DataFrame(X['assess']).rename(columns={'c':'comm','n':'res_parcels','medval':'med_home_value','medyr':'med_year_built'})
for col in ['res_parcels','med_home_value','med_year_built']: asx[col] = pd.to_numeric(asx[col])
badval = asx.med_home_value < 150000   # medians this low mean parking stalls / storage units dominate the residential roll
asx.loc[badval, ['med_home_value','med_year_built']] = np.nan
pm = pd.DataFrame(X['permits']).rename(columns={'c':'comm','n':'permits','units':'new_units','cost':'permit_value','newres':'new_res_permits'})
for col in ['permits','new_units','permit_value','new_res_permits']: pm[col] = pd.to_numeric(pm[col]).fillna(0)
oo = pd.DataFrame(X['openold']).rename(columns={'c':'comm','n':'open_over_90d'}); oo['open_over_90d'] = pd.to_numeric(oo.open_over_90d)
K = K.merge(asx, on='comm', how='left').merge(pm, on='comm', how='left').merge(oo, on='comm', how='left')
K['built'] = K.comm.map(age)
# CEI matrix by CSA (map via community names list)
cei = pd.DataFrame(X['cei'], columns=['csa','domain','indicator','value','status','year'])
cei['indicator'] = cei.indicator.str.replace('®','',regex=False).str.replace(r'\s+',' ',regex=True).str.strip()
ceiw = cei.pivot_table(index='csa', columns='indicator', values='value', aggfunc='first')
name2csa = {}
for csa, comms in X['csaComms'].items():
    for nm in re.split(r'\s*,\s*', comms or ''):
        if nm: name2csa[nm.strip().upper()] = csa
K['csa_citylist'] = K.name.str.upper().map(name2csa)
K['cei_csa'] = K.csa   # matrix values taken from the same area as the demographic values (area IDs are shared: r=0.98 on low income)
keep = {'*Total weighted score':'equity_score','Walk Score':'walk_score','Transit Score':'transit_score','Bike Score':'bike_score','Green space area':'green_space','Community spaces (per 100,000)':'community_spaces_per100k',
        'Walk to healthier food stores':'healthy_food_walk','Core housing need':'core_housing_need','Unemployment rate (aged 25-64)':'unemp_2564','High school graduation rate':'hs_grad','Post-secondary education':'post_secondary',
        'Property crime rate (per 100,000)':'property_crime_per100k','Violent crime rate (per 100,000)':'violent_crime_per100k','Self-perceived health':'self_health','Diabetes prevalence':'diabetes','Mental illness prevalence':'mental_illness','COPD prevalence':'copd',
        'Municipal voting':'voting','Early Development Instrument (EDI)':'edi','Youth low income transit pass sales':'youth_lowinc_pass'}
missing_ind = [k for k in keep if k not in ceiw.columns]
cw = ceiw[[k for k in keep if k in ceiw.columns]].rename(columns=keep)
K = K.merge(cw, left_on='cei_csa', right_index=True, how='left')
R['cei_missing_indicators'] = missing_ind
for col in ['green_space','healthy_food_walk','core_housing_need','unemp_2564','hs_grad','post_secondary','self_health','diabetes','mental_illness','copd','voting','edi','youth_lowinc_pass']:
    if col in K: K[col] = pd.to_numeric(K[col]) * 100   # matrix stores shares as fractions; convert to percent

# ---------- 311 measures ----------
b1 = pd.DataFrame(B['b1'], columns=['comm','s','n']); b1['service'] = b1.s.map(lambda i: S[i]); b1['cat'] = b1.service.str.split(' - ').str[0].map(CAT)
catw = b1.pivot_table(index='comm', columns='cat', values='n', aggfunc='sum', fill_value=0)
K = K.merge(catw, left_on='comm', right_index=True, how='left')
for c in CAT.values(): K[c] = K[c].fillna(0)
K['infra'] = K['Roads'] + K['Water & sewer'] + K['Parks & trees']; K['req30'] = K[list(CAT.values())].sum(axis=1)
b2 = pd.DataFrame(B['b2'], columns=['comm','src','n']); p2 = b2.pivot_table(index='comm', columns='src', values='n', aggfunc='sum', fill_value=0)
p2['all_req'] = p2.sum(axis=1); p2['app_share'] = p2.App / p2.all_req * 100
K = K.merge(p2[['all_req','app_share','App']], left_on='comm', right_index=True, how='left')
K = K[K['pop'] >= 500].copy()
per = lambda col: K[col] / K['pop'] * 1000 / 2
K['infra_rate'] = per('infra'); K['req30_rate'] = per('req30'); K['all_rate'] = per('all_req')
for c in CAT.values(): K[c + ' rate'] = per(c)
K['permits_per1k'] = K.permits / K['pop'] * 1000 / 2
K['units_per1k'] = K.new_units / K['pop'] * 1000 / 2
K['homes_vs_2021'] = K.res_parcels / K.total_private_households
# closure (standardized)
A2 = A[A.comm.isin(K.comm)].copy()
city = A2.groupby(['service','y'])[['n','w7','w30','o90']].sum(); city['p7'] = city.w7/city.n; city['p90'] = city.o90/city.n; city['p30'] = city.w30/city.n
A2 = A2.merge(city[['p7','p30','p90']], left_on=['service','y'], right_index=True)
A2['e7'] = A2.n*A2.p7; A2['e30'] = A2.n*A2.p30; A2['e90'] = A2.n*A2.p90
cc = A2.groupby('comm')[['n','w7','e7','w30','e30','o90','e90']].sum()
cc['close7_ratio'] = cc.w7/cc.e7*100; cc['close7_pct'] = cc.w7/cc.n*100; cc['over90_pct'] = cc.o90/cc.n*100
K = K.merge(cc[['n','w7','e7','close7_ratio','close7_pct','over90_pct']].rename(columns={'n':'closed_n'}), left_on='comm', right_index=True, how='left')
K['not_closed_pct'] = (K.req30 - K.closed_n) / K.req30 * 100
K['log_income'] = np.log(K.income)
K = K.sort_values('income'); cwt = K['pop'].cumsum()/K['pop'].sum(); K['inc_q'] = np.clip(np.ceil(cwt*5), 1, 5).astype(int)
K['ne_q'] = pd.qcut(K.noeng.rank(method='first'), 4, labels=[1,2,3,4]).astype(int)
R['cei_unmatched_comms'] = int(K.csa_citylist.isna().sum()); R['citylist_disagree'] = int((K.csa_citylist.notna() & (K.csa_citylist != K.csa)).sum())
R['n_comm'] = len(K); R['pop'] = int(K['pop'].sum()); R['req_all'] = int(K.all_req.sum()); R['req30'] = int(K.req30.sum()); R['closed'] = int(A2.n.sum())
R['quadrant_counts'] = K.groupby('quadrant').size().to_dict()

# ---------- regression helper (weighted least squares on log rate) ----------
def wls(df, y, xs, w='pop', cl='csa'):
    df = df.dropna(subset=[y] + xs + [w])
    Xm = np.column_stack([np.ones(len(df))] + [df[x].values for x in xs]); yy = np.log(df[y].values + 1); ww = np.sqrt(df[w].values)
    Xw = Xm*ww[:,None]; beta, *_ = np.linalg.lstsq(Xw, yy*ww, rcond=None)
    res = yy - Xm@beta; n, k = Xm.shape; s2 = (ww**2*res**2).sum()/(n-k); cov = s2*np.linalg.inv(Xw.T@Xw)
    se = np.sqrt(np.diag(cov)); yw = np.average(yy, weights=ww**2); r2 = 1 - (ww**2*res**2).sum()/(ww**2*(yy-yw)**2).sum()
    out = {x: (round(b,4), round(b/s,2)) for x, b, s in zip(['const']+xs, beta, se)} | {'n': n, 'r2': round(r2,3)}
    if cl and cl in df and df[cl].nunique() < n:   # CR1 cluster-robust t (communities clustered within areas)
        bread = np.linalg.inv(Xw.T@Xw); meat = np.zeros((k,k)); g = df[cl].values; G_ = len(set(g))
        for c in set(g):
            m = g == c; u = (Xw[m]*(res[m]*ww[m])[:,None]).sum(0); meat += np.outer(u,u)
        vc = bread@meat@bread * G_/(G_-1)*(n-1)/(n-k); out['t_cl'] = {x: round(b/s,2) for x, b, s in zip(['const']+xs, beta, np.sqrt(np.diag(vc)))}
    return out
def eff(b): return round((math.exp(b*4)-1)*100, 1)   # 1% -> 5% non-English
base = ['log_income','renter','noeng','dist_km']
models = {}
models['M1 community: income, renters, no-English, distance'] = wls(K, 'infra_rate', base)
K['age_yrs'] = 2025 - K.built; K['pre1970'] = (K.built <= 1968).astype(float)   # 1 = community existed by 1968 (start of the census series)
models['M2 + community age (first census year)'] = wls(K, 'infra_rate', base + ['age_yrs','pre1970'])
K['house_age'] = 2025 - K.med_year_built
models['M3 + median year homes built (assessments)'] = wls(K, 'infra_rate', base + ['house_age'])
K['growth'] = K.new_units / K['pop'] * 100
models['M4 + age + growth since 2021 (new housing units)'] = wls(K, 'infra_rate', base + ['age_yrs','pre1970','growth'])
models['M5 + age + home value'] = wls(K.assign(log_val=np.log(K.med_home_value)), 'infra_rate', base + ['age_yrs','pre1970','log_val'])
models['M6 M2 excluding NE quadrant'] = wls(K[K.quadrant != 'NE'], 'infra_rate', base + ['age_yrs','pre1970'])
models['M7 M2 roads only'] = wls(K.assign(r=K['Roads rate']), 'r', base + ['age_yrs','pre1970'])
models['M8 M2 water & sewer only'] = wls(K.assign(r=K['Water & sewer rate']), 'r', base + ['age_yrs','pre1970'])
models['M9 M2 parks & trees only'] = wls(K.assign(r=K['Parks & trees rate']), 'r', base + ['age_yrs','pre1970'])
models['M10 M2 all 30 request types'] = wls(K, 'req30_rate', base + ['age_yrs','pre1970'])
models['M11 M2 all request types (every 311 service)'] = wls(K, 'all_rate', base + ['age_yrs','pre1970'])
models['M12 M2 excluding communities within 3 km of downtown'] = wls(K[K.dist_km > 3], 'infra_rate', base + ['age_yrs','pre1970'])
models['M13 M2 unweighted'] = wls(K.assign(one=1.0), 'infra_rate', base + ['age_yrs','pre1970'], w='one')
models['M14 M2 newcomers instead of no-English'] = wls(K, 'infra_rate', ['log_income','renter','newcomer','dist_km','age_yrs','pre1970'])
models['M15 M2 visible minority instead of no-English'] = wls(K, 'infra_rate', ['log_income','renter','vismin','dist_km','age_yrs','pre1970'])
# area (CSA) level
G = K.groupby('csa').agg(pop=('pop','sum'), infra=('infra','sum'), income=('income','first'), renter=('renter','first'), noeng=('noeng','first'), dist_km=('dist_km','mean'), age_yrs=('age_yrs','mean'), pre1970=('pre1970','mean')).reset_index()
G['infra_rate'] = G.infra/G['pop']*500; G['log_income'] = np.log(G.income)
models['M16 area level (CSA), with age'] = wls(G, 'infra_rate', base + ['age_yrs','pre1970'], cl=None)
# ---------- sensitivity checks ----------
SENS = {}
DEFECT_OUT = ['Roads - Debris on Street/Sidewalk/Boulevard','Roads - Snow and Ice Control','Roads - Dead Animal Pick-Up','Roads - Pathway Snow and Ice Concerns','Parks - Garbage - GIS']
dd = b1[b1.service.isin(DEFECT_OUT)].groupby('comm').n.sum()
K['infra_defect'] = K.infra - K.comm.map(dd).fillna(0); K['infra_defect_rate'] = K.infra_defect / K['pop'] * 500
R['defect_share_excluded'] = round(float(1 - K.infra_defect.sum()/K.infra.sum())*100, 1)
SENS['Defects only (no snow, debris, dead animals, park garbage)'] = wls(K, 'infra_defect_rate', base + ['age_yrs','pre1970'])
# demographics taken from the area in the City's own community lists (where available)
alt = K.copy(); ok = alt.csa_citylist.notna()
for col, key in [('income','Median Income'),('renter','Renter'),('noeng','No English Knowledge')]:
    alt.loc[ok, col] = alt.loc[ok, 'csa_citylist'].map(lambda c: C['ind'][c].get(key))
alt['log_income'] = np.log(alt.income); alt['csa'] = alt.csa.where(~ok, alt.csa_citylist)
SENS["Area from the City's community lists"] = wls(alt, 'infra_rate', base + ['age_yrs','pre1970'])
def rawgap(df, col='infra'):
    q = pd.qcut(df.noeng.rank(method='first'), 4, labels=[1,2,3,4]).astype(int)
    r = lambda k: df[q==k][col].sum()/df[q==k]['pop'].sum()
    return round((1 - r(4)/r(1))*100, 1)
R['sens'] = {k: dict(eff=eff(v['noeng'][0]), t=v['noeng'][1], t_cl=v['t_cl']['noeng'], n=v['n']) for k, v in SENS.items()}
R['sens_rawgap'] = {'Defects only (no snow, debris, dead animals, park garbage)': rawgap(K, 'infra_defect'), "Area from the City's community lists": rawgap(alt)}
R['rawgap'] = rawgap(K)
# growth since 2021 by language quartile (for the population-date limitation)
R['growth_by_neq'] = {int(k): round(float(d.new_units.sum()/d['pop'].sum()*100),2) for k, d in K.assign(q=pd.qcut(K.noeng.rank(method='first'),4,labels=[1,2,3,4]).astype(int)).groupby('q')}
R['growth_spearman_noeng'] = round(float(K[['noeng','growth']].corr(method='spearman').iloc[0,1]),3) if 'growth' in K else None
R['models'] = models
R['effects'] = {k: eff(v['noeng'][0]) for k, v in models.items() if 'noeng' in v}
R['t_cl'] = {k: v['t_cl'].get('noeng', v['t_cl'].get('newcomer', v['t_cl'].get('vismin'))) for k, v in models.items() if 't_cl' in v}
# cluster bootstrap CI at CSA level for M2
rng = np.random.default_rng(42); csas = K.csa.unique(); bs = []
for _ in range(1000):
    pick = rng.choice(csas, len(csas), replace=True)
    df = pd.concat([K[K.csa == c] for c in pick])
    bs.append(wls(df, 'infra_rate', base + ['age_yrs','pre1970'])['noeng'][0])
lo, hi = np.percentile(bs, [2.5, 97.5]); R['bootstrap_M2'] = {'b_lo': round(lo,4), 'b_hi': round(hi,4), 'eff_lo': eff(hi), 'eff_hi': eff(lo), 'point': R['effects']['M2 + community age (first census year)']}
# descriptive groups
def grp(df, key):
    return {int(k): dict(comms=len(d), pop=int(d['pop'].sum()), ne=round(float(np.average(d.noeng, weights=d['pop'])),1), rate=round(d.infra.sum()/d['pop'].sum()*500,1),
            inc=int(round(float(np.average(d.income, weights=d['pop'])))), built=int(round(float(np.average(d.built.fillna(1968), weights=d['pop'])))), dist=round(float(np.average(d.dist_km, weights=d['pop'])),1)) for k, d in df.groupby(key)}
R['neq'] = grp(K, 'ne_q')
M = K[(K.built >= 1975) & (K.built <= 2000)].copy(); M['t'] = pd.qcut(M.noeng.rank(method='first'), 3, labels=[1,2,3]).astype(int); R['matched'] = grp(M, 't')
R['neq_nonNE'] = grp(K[K.quadrant != 'NE'].assign(t=lambda d: pd.qcut(d.noeng.rank(method='first'), 4, labels=[1,2,3,4]).astype(int)), 't')
# category gaps (raw, top vs bottom no-English quartile)
R['cat_gap'] = {c: [round(K[K.ne_q==q][c].sum()/K[K.ne_q==q]['pop'].sum()*500,1) for q in [1,2,3,4]] for c in CAT.values()}
# per-year (closed requests only, infra cats)
Ai = A2[A2.cat.isin(['Roads','Water & sewer','Parks & trees'])].merge(K[['comm','ne_q','pop']], on='comm')
R['by_year'] = {int(y): {int(q): round(d[d.ne_q==q].n.sum()/K[K.ne_q==q]['pop'].sum()*1000,1) for q in [1,2,3,4]} for y, d in Ai.groupby('y')}
# closure by income & by no-English (standardized)
def clos(key):
    g = A2.merge(K[['comm',key]], on='comm').groupby(key)[['n','w7','e7','w30','e30','o90','e90']].sum()
    return {int(k): dict(n=int(r.n), p7=round(r.w7/r.n*100,1), r7=round(r.w7/r.e7*100,1), r30=round(r.w30/r.e30*100,1), r90=round(r.o90/r.e90*100,1)) for k, r in g.iterrows()}
R['closure_inc'] = clos('inc_q'); R['closure_ne'] = clos('ne_q')
R['closure_cat_inc'] = {c: {int(q): round(v,1) for q, v in (lambda g: (g.w7/g.e7*100))(A2[A2.cat==c].merge(K[['comm','inc_q']], on='comm').groupby('inc_q')[['w7','e7']].sum()).items()} for c in CAT.values()}
gq = K.groupby('inc_q')
R['incq'] = {int(k): dict(comms=len(d), lo=int(d.income.min()), hi=int(d.income.max()), rate=round(d.infra.sum()/d['pop'].sum()*500,1), app=round(d.App.sum()/d.all_req.sum()*100,1) if 'App' in d else None) for k, d in gq}
app = b2[b2.comm.isin(K.comm)].merge(K[['comm','inc_q','ne_q']], on='comm')
R['app_inc'] = {int(k): round(d[d.src=='App'].n.sum()/d.n.sum()*100,1) for k, d in app.groupby('inc_q')}
R['app_ne'] = {int(k): round(d[d.src=='App'].n.sum()/d.n.sum()*100,1) for k, d in app.groupby('ne_q')}
# reconciliation checks
R['over90_share'] = round(float(A2.o90.sum()/A2.n.sum()*100), 1)
R['home_value_suppressed'] = K[K.med_home_value.isna() & K.res_parcels.notna()].name.tolist()
R['check'] = dict(closed_in_A=int(A2.n.sum()), all_req_30=int(K.req30.sum()), closed_share=round(A2.n.sum()/K.req30.sum()*100,1))
# correlations among demographic indicators
R['corr'] = K[['noeng','newcomer','vismin','income','renter','built','dist_km']].corr().round(2).to_dict()

# ---------- expected rate (model without language) and reporting gap ----------
xs_e = ['log_income','renter','dist_km','age_yrs','pre1970']; d = K.dropna(subset=xs_e)
Xe = np.column_stack([np.ones(len(d))] + [d[x].values for x in xs_e]); we = np.sqrt(d['pop'].values)
be = np.linalg.lstsq(Xe*we[:,None], np.log(d.infra_rate.values+1)*we, rcond=None)[0]
ex = np.exp(Xe@be) - 1; smear = np.average(d.infra_rate.values/ex, weights=d['pop'].values)
K['expected_rate'] = pd.Series(ex*smear, index=d.index); K['report_gap_pct'] = (K.infra_rate/K.expected_rate - 1)*100
R['smear'] = round(float(smear), 4)
# ---------- Calgary figures for the community profile ----------
wavg = lambda col, w='pop': float(np.average(K[col].dropna(), weights=K.loc[K[col].notna(), w]))
hh = 'total_private_households'
city = {}
for col in ['kids_pct','seniors_pct','one_parent_families_per','newcomer','noeng','vismin','indigenous','moved','income','lim_1864','lim_017','unemployment_rate_per','labour_participation_rate',
            'post_secondary','walk_score','transit_score','bike_score','transit_work','green_space','community_spaces_per100k','healthy_food_walk','self_health','diabetes','mental_illness',
            'property_crime_per100k','violent_crime_per100k','voting','equity_score','med_year_built']:
    city[col] = wavg(col)
for col in ['house_size_1_percent','renter','detached','core_housing_need']: city[col] = wavg(col, hh)   # household-based shares
city['med_home_value'] = float(K.med_home_value.median())   # median of community medians
city['pop'] = float(K['pop'].mean())   # average community size
city['avg_household_size'] = float(K['pop'].sum()/K[hh].sum())
tot = lambda col: float(K[col].sum()/K['pop'].sum()*500)
for col in ['all_rate','infra_rate','Roads rate','Water & sewer rate','Parks & trees rate','Graffiti & encampments rate','Bylaw rate','Waste carts rate']:
    city[col] = tot(col.replace(' rate','') if col not in ['all_rate','infra_rate'] else {'all_rate':'all_req','infra_rate':'infra'}[col])
city['expected_rate'] = city['infra_rate']; city['report_gap_pct'] = 0.0
city['permits_per1k'] = float(K.permits.sum()/K['pop'].sum()*500); city['units_per1k'] = float(K.new_units.sum()/K['pop'].sum()*500)
city['app_share'] = float(K.App.sum()/K.all_req.sum()*100) if 'App' in K else None
city['close7_pct'] = float(K.w7.sum()/K.closed_n.sum()*100); city['close7_ratio'] = float(K.w7.sum()/K.e7.sum()*100)
city['not_closed_pct'] = float((K.req30.sum()-K.closed_n.sum())/K.req30.sum()*100)
R['city'] = {k: round(v, 4) for k, v in city.items()}
json.dump(R, open(D+'reanalysis.json','w'), indent=1, default=str)
K.to_csv(D+'communities_enriched.csv', index=False)
print(json.dumps({k: R[k] for k in ['n_comm','pop','req_all','req30','closed','effects','bootstrap_M2','neq','matched','neq_nonNE','cat_gap','by_year','closure_inc','closure_ne','app_inc','app_ne','check','cei_missing_indicators','cei_unmatched_comms','quadrant_counts']}, indent=0, default=str))
for k, v in models.items(): print(k, '| noeng' , v.get('noeng'), '| r2', v['r2'], '| n', v['n'])
