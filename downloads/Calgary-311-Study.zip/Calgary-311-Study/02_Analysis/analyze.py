import json, math
import numpy as np, pandas as pd
import os
R = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'raw') + '/'
S = ["Roads - Pothole Maintenance","Roads - Streetlight Maintenance","Roads - Traffic or Pedestrian Light Repair","Roads - Sidewalk - Curb and Gutter Repair","Roads - Roadway Maintenance","Roads - Backlane Maintenance","Roads - Debris on Street/Sidewalk/Boulevard","Roads - Signs - Missing - Damaged","Roads - Snow and Ice Control","Roads - Dead Animal Pick-Up","Roads - Pathway Concerns","Roads - Pathway Snow and Ice Concerns","WATS - Catch Basin Concerns","WATS - Sewage Back-up","WATS - Sewer Maintenance","WATS - Water Main Break or Leak","WATS - Service and Main Valve Issues","Parks - Tree Concern - GIS","Parks - Garbage - GIS","Parks - Maintenance - GIS","Parks - Infrastructure - GIS","Corporate - Graffiti Concerns","Corporate - Encampment Concerns","Bylaw - Snow and Ice on Sidewalk","Bylaw - Long Grass - Weeds Infraction","Bylaw - Material on Public Property","WRS - Cart Management","WRS - Waste - Residential","WRS - Recycling - Blue Cart","WRS - Compost - Green Cart"]
A = pd.DataFrame(json.load(open(R+'A.json')), columns=['comm','s','y','n','med','avg','w7','w30','o90'])
B = json.load(open(R+'B.json')); C = json.load(open(R+'C.json'))
A['service'] = A.s.map(lambda i: S[i])

# community table
pop = {p[0]: p[2] for p in C['pop'] if p[2] is not None}
rows = []
for c, info in C['comms'].items():
    csa = C['map'].get(c)
    if not csa or c not in pop: continue
    ind = C['ind'][csa]
    lat, lon = info['lat'], info['lon']
    dist = math.hypot((lat-51.0447)*111, (lon+114.0719)*111*math.cos(math.radians(51)))
    rows.append(dict(comm=c, name=info['name'].title(), pop=pop[c], csa=csa, income=ind.get('Median Income'),
        lowinc=ind.get('LIM-AT 18-64 years'), noeng=ind.get('No English Knowledge'), newcomer=ind.get('Newcomers'),
        renter=ind.get('Renter'), vismin=ind.get('Visible Minority'), dist_km=dist, lat=lat, lon=lon))
K = pd.DataFrame(rows)
K = K[K['pop'] >= 500].copy()
# population-weighted income quintiles
K = K.sort_values('income'); cw = K['pop'].cumsum()/K['pop'].sum()
K['q'] = np.minimum((cw*5).apply(math.ceil), 5).astype(int)
K.loc[K.q < 1, 'q'] = 1
print('communities', len(K), 'pop', K['pop'].sum())
print(K.groupby('q').agg(n=('comm','size'), pop=('pop','sum'), inc_min=('income','min'), inc_max=('income','max'), noeng=('noeng','mean'), newc=('newcomer','mean'), renter=('renter','mean'), dist=('dist_km','mean')).round(1))

# ---- 1. reporting rates (selected 30 services, non-duplicate, 2 yrs)
b1 = pd.DataFrame(B['b1'], columns=['comm','s','n']); b1['service'] = b1.s.map(lambda i: S[i])
b1 = b1[b1.comm.isin(K.comm)]
b1['cat'] = b1.service.str.split(' - ').str[0]
vol = b1.groupby('comm').n.sum().rename('req')
K = K.merge(vol, on='comm', how='left').fillna({'req': 0})
K['per1k_yr'] = K.req / K['pop'] * 1000 / 2
cat = b1.groupby(['comm','cat']).n.sum().unstack(fill_value=0)
q = K.set_index('comm')
def rate_by_q(series):
    d = q[['q','pop']].join(series.rename('x')).fillna(0)
    g = d.groupby('q').agg(x=('x','sum'), pop=('pop','sum'))
    return (g.x/g['pop']*1000/2).round(1)
print('\nRequests per 1,000 residents per year, by income quintile (1=lowest)')
print(rate_by_q(vol).to_string())
for c in cat.columns: print(c, rate_by_q(cat[c]).to_dict())
# infrastructure-only (roads+water+parks)
infra = b1[b1.cat.isin(['Roads','WATS','Parks'])].groupby('comm').n.sum()
print('infra', rate_by_q(infra).to_dict())

# ---- 2. app share
b2 = pd.DataFrame(B['b2'], columns=['comm','src','n']); b2 = b2[b2.comm.isin(K.comm)]
p2 = b2.pivot_table(index='comm', columns='src', values='n', aggfunc='sum', fill_value=0)
p2['tot'] = p2.sum(axis=1)
d = q[['q']].join(p2)
g = d.groupby('q')[['App','tot']].sum(); print('\nApp share by quintile', (g.App/g.tot*100).round(1).to_dict())
alltot = d.groupby('q').tot.sum(); popq = q.groupby('q')['pop'].sum()
print('ALL services per 1k/yr', (alltot/popq*1000/2).round(1).to_dict())

# ---- 3. closure speed, like-for-like (indirect standardization by service x year)
A2 = A[A.comm.isin(K.comm)].merge(K[['comm','q','income','dist_km']], on='comm')
city = A[A.comm.isin(K.comm)].groupby(['service','y'])[['n','w7','w30','o90']].sum()
city['p7'] = city.w7/city.n; city['p90'] = city.o90/city.n
A2 = A2.merge(city[['p7','p90']], left_on=['service','y'], right_index=True)
A2['e7'] = A2.n*A2.p7; A2['e90'] = A2.n*A2.p90
g = A2.groupby('q')[['n','w7','e7','o90','e90']].sum()
g['closed_7d_pct'] = (g.w7/g.n*100).round(1); g['ratio_vs_expected_7d'] = (g.w7/g.e7).round(3)
g['over90_pct'] = (g.o90/g.n*100).round(2); g['ratio_vs_expected_90'] = (g.o90/g.e90).round(3)
print('\nClosure speed by quintile (standardized for service mix and year)'); print(g)
# per-service medians by quintile (n-weighted median of cell medians as approx) and 7d share
print('\nShare closed within 7 days by service and quintile')
t = A2.groupby(['service','q'])[['n','w7']].sum(); t['p'] = (t.w7/t.n*100).round(0)
print(t.p.unstack().join(A2.groupby('service').n.sum().rename('N')).sort_values('N', ascending=False).to_string())
K.to_csv(R+'../communities.csv', index=False); A2.to_csv(R+'../closure_cells.csv', index=False)
