"""Step 1 of the reproduction: download every source extract the study uses from City of Calgary Open Data
(data.calgary.ca) and save it as CSV in 01_Source_Data.

Usage (from the package folder):  python download_data.py
Needs only Python 3 (standard library) and normal internet access. Takes about a minute.

Each query's raw response is also saved in 01_Source_Data/api_responses/<name>.json. If that file is already
there, it is reused instead of downloading again (delete the folder to force a fresh download).

Open Data changes over time: 311 requests get closed, merged as duplicates or re-coded after the study's
download (October 20-21, 2026), and the property roll moves to a new year each January. A fresh download will
therefore differ slightly from the packaged extracts. To reproduce the published figures exactly, use the
packaged 01_Source_Data files; to test whether the findings still hold, use a fresh download.
"""
import csv, json, os, urllib.parse, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, '01_Source_Data')
CACHE = os.path.join(OUT, 'api_responses')
API = 'https://data.calgary.ca/resource/'

PERIOD = "requested_date>='2024-10-01' AND requested_date<'2026-10-01'"     # study period: Oct 1, 2024 - Sep 30, 2026
NOT_DUP = "status_description not like 'Duplicate%'"

# The 30 common resident-reported service types (the first 21 are the infrastructure measure).
STUDY_TYPES = [
    "Roads - Pothole Maintenance", "Roads - Streetlight Maintenance", "Roads - Traffic or Pedestrian Light Repair",
    "Roads - Sidewalk - Curb and Gutter Repair", "Roads - Roadway Maintenance", "Roads - Backlane Maintenance",
    "Roads - Debris on Street/Sidewalk/Boulevard", "Roads - Signs - Missing - Damaged", "Roads - Snow and Ice Control",
    "Roads - Dead Animal Pick-Up", "Roads - Pathway Concerns", "Roads - Pathway Snow and Ice Concerns",
    "WATS - Catch Basin Concerns", "WATS - Sewage Back-up", "WATS - Sewer Maintenance", "WATS - Water Main Break or Leak",
    "WATS - Service and Main Valve Issues", "Parks - Tree Concern - GIS", "Parks - Garbage - GIS", "Parks - Maintenance - GIS",
    "Parks - Infrastructure - GIS", "Corporate - Graffiti Concerns", "Corporate - Encampment Concerns",
    "Bylaw - Snow and Ice on Sidewalk", "Bylaw - Long Grass - Weeds Infraction", "Bylaw - Material on Public Property",
    "WRS - Cart Management", "WRS - Waste - Residential", "WRS - Recycling - Blue Cart", "WRS - Compost - Green Cart"]
IN_TYPES = "service_name in(" + ",".join("'" + s.replace("'", "''") + "'" for s in STUDY_TYPES) + ")"
DAYS = "date_diff_d(closed_date,requested_date)"

# name: (dataset id, SoQL parameters)
QUERIES = {
    # ---- 311 Service Requests (iahh-g8bj) ----
    'closed': ('iahh-g8bj', {
        '$select': f"comm_code,service_name,date_extract_y(requested_date) as y,count(*) as n,median({DAYS}) as med,"
                   f"avg({DAYS}) as avg,sum(case({DAYS}<=7,1,true,0)) as w7,sum(case({DAYS}<=30,1,true,0)) as w30,"
                   f"sum(case({DAYS}>90,1,true,0)) as o90",
        '$where': f"{PERIOD} AND status_description='Closed' AND {IN_TYPES}",
        '$group': 'comm_code,service_name,y'}),
    'by_service': ('iahh-g8bj', {
        '$select': 'comm_code,service_name,count(*) as n',
        '$where': f"{PERIOD} AND {NOT_DUP} AND {IN_TYPES}", '$group': 'comm_code,service_name'}),
    'by_channel': ('iahh-g8bj', {
        '$select': 'comm_code,source,count(*) as n', '$where': f"{PERIOD} AND {NOT_DUP}", '$group': 'comm_code,source'}),
    'by_year': ('iahh-g8bj', {
        '$select': 'comm_code,date_extract_y(requested_date) as y,count(*) as n',
        '$where': f"{PERIOD} AND {NOT_DUP}", '$group': 'comm_code,y'}),
    'centrepoints': ('iahh-g8bj', {
        '$select': 'comm_code,comm_name,latitude,longitude,count(*) as n',
        '$where': "requested_date>='2025-01-01' AND requested_date<'2026-10-01'",
        '$group': 'comm_code,comm_name,latitude,longitude'}),
    'open_old': ('iahh-g8bj', {
        '$select': 'comm_code,count(*) as n',
        '$where': "status_description='Open' AND requested_date<'2026-07-22'", '$group': 'comm_code'}),
    # ---- 2021 Census by community ----
    'census_pop_age': ('f9wk-wej9', {
        '$select': 'community_code,community_name,total_pop_household,pop_age_0_to_14_percent,'
                   'pop_age_65_to_84_percent,pop_age_85_and_over_percent'}),
    'census_households': ('msjx-5ygv', {
        '$select': 'community_code,total_private_households,avg_household_size,house_size_1_percent,'
                   'one_parent_families_per,married_with_children_per'}),
    'census_employment': ('isek-k4ja', {
        '$select': 'community_code,labour_participation_rate,unemployment_rate_per,employment_rate_per,'
                   'top_1_industry,top_1_occupation'}),
    # ---- Calgary Equity Index ----
    'equity_overlay': ('7g5f-dkmi', {
        '$select': 'area_id,attribute,value', '$where': "area_type='CSA' AND category='Demographic'"}),
    'equity_areas': ('7g5f-dkmi', {
        '$select': 'area_id,multipolygon', '$where': "area_type='CSA' AND category='Demographic' AND attribute='Renter'"}),
    'equity_matrix': ('xeek-u7v8', {
        '$select': 'csa_label,domain_label,indicator_label,value,status,data_currency,communities'}),
    # ---- Community age, property roll, building permits ----
    'first_year_500': ('jtpc-xgsh', {
        '$select': 'comm_code,min(census_year) as first_year', '$where': 'population>=500', '$group': 'comm_code'}),
    'assessments': ('4bsw-nn7w', {
        '$select': 'comm_code,count(*) as n,median(re_assessed_value) as medval,median(year_of_construction) as medyr',
        '$where': "assessment_class='RE' AND re_assessed_value>0", '$group': 'comm_code'}),
    'permits': ('c2es-76ed', {
        '$select': 'communitycode,count(*) as n,sum(housingunits) as units,sum(estprojectcost) as cost',
        '$where': "applieddate>='2024-10-01' AND applieddate<'2026-10-01'", '$group': 'communitycode'}),
    'permits_new_res': ('c2es-76ed', {
        '$select': 'communitycode,count(*) as n',
        '$where': "applieddate>='2024-10-01' AND applieddate<'2026-10-01' AND permitclassmapped='Residential' "
                  "AND workclassgroup='New'", '$group': 'communitycode'}),
}


def url_for(name):
    dataset, params = QUERIES[name]
    return API + dataset + '.json?' + urllib.parse.urlencode(dict(params, **{'$limit': 50000}))


def get(name):
    os.makedirs(CACHE, exist_ok=True)
    path = os.path.join(CACHE, name + '.json')
    if not os.path.exists(path):
        with urllib.request.urlopen(url_for(name), timeout=300) as r:
            data = r.read()
        with open(path, 'wb') as f:
            f.write(data)
    with open(path, encoding='utf-8') as f:
        rows = json.load(f)
    if len(rows) >= 50000:
        raise SystemExit(f'{name}: 50,000 rows returned, raise $limit')
    print(f'{name:18s} {len(rows):6d} rows')
    return rows


def write(filename, header, rows):
    with open(os.path.join(OUT, filename), 'w', encoding='utf-8', newline='') as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)


def g(r, k):
    v = r.get(k)
    return '' if v is None else v


def point_in_polygon(lon, lat, multipolygon):
    """Even-odd rule over every ring of a GeoJSON MultiPolygon."""
    inside = False
    for polygon in multipolygon['coordinates']:
        for ring in polygon:
            j = len(ring) - 1
            for i in range(len(ring)):
                xi, yi = ring[i][0], ring[i][1]
                xj, yj = ring[j][0], ring[j][1]
                if (yi > lat) != (yj > lat) and lon < (xj - xi) * (lat - yi) / (yj - yi) + xi:
                    inside = not inside
                j = i
    return inside


def main():
    os.makedirs(OUT, exist_ok=True)
    R = {name: get(name) for name in QUERIES}

    write('311_closed_requests_by_community_service_year.csv',
          ['community_code', 'service_name', 'request_year', 'closed_requests', 'median_days_to_close', 'mean_days_to_close',
           'closed_within_7_days', 'closed_within_30_days', 'took_over_90_days'],
          [[g(r, 'comm_code'), r['service_name'], r['y'], r['n'], g(r, 'med'), round(float(r['avg']), 1) if r.get('avg') else '',
            r['w7'], r['w30'], r['o90']] for r in R['closed']])
    write('311_requests_by_community_service.csv', ['community_code', 'service_name', 'requests'],
          [[g(r, 'comm_code'), r['service_name'], r['n']] for r in R['by_service']])
    write('311_requests_by_community_channel.csv', ['community_code', 'channel', 'requests'],
          [[g(r, 'comm_code'), g(r, 'source'), r['n']] for r in R['by_channel']])
    write('311_requests_by_community_year.csv', ['community_code', 'request_year', 'requests'],
          [[g(r, 'comm_code'), r['y'], r['n']] for r in R['by_year']])
    write('311_community_centrepoints.csv',
          ['community_code', 'community_name', 'centrepoint_latitude', 'centrepoint_longitude', 'requests_2025_onward'],
          [[r['comm_code'], g(r, 'comm_name'), g(r, 'latitude'), g(r, 'longitude'), r['n']] for r in R['centrepoints']
           if r.get('comm_code')])
    write('311_open_requests_over_90_days_by_community.csv', ['community_code', 'open_requests_older_than_90_days'],
          [[g(r, 'comm_code'), r['n']] for r in R['open_old']])

    write('census2021_population_by_community.csv', ['community_code', 'community_name', 'population_2021'],
          [[r['community_code'], g(r, 'community_name'), g(r, 'total_pop_household')] for r in R['census_pop_age']])
    write('census2021_age_by_community.csv',
          ['community_code', 'total_pop_household', 'pop_age_0_to_14_percent', 'pop_age_65_to_84_percent',
           'pop_age_85_and_over_percent'],
          [[r['community_code'], g(r, 'total_pop_household'), g(r, 'pop_age_0_to_14_percent'),
            g(r, 'pop_age_65_to_84_percent'), g(r, 'pop_age_85_and_over_percent')] for r in R['census_pop_age']])
    hh = ['total_private_households', 'avg_household_size', 'house_size_1_percent', 'one_parent_families_per',
          'married_with_children_per']
    write('census2021_households_by_community.csv', ['community_code'] + hh,
          [[r['community_code']] + [g(r, k) for k in hh] for r in R['census_households']])
    em = ['labour_participation_rate', 'unemployment_rate_per', 'employment_rate_per', 'top_1_industry', 'top_1_occupation']
    write('census2021_employment_by_community.csv', ['community_code'] + em,
          [[r['community_code']] + [g(r, k) for k in em] for r in R['census_employment']])

    # Equity Index overlay: one row per area, one column per demographic attribute
    attrs = ['Indigenous', 'Moved in the last year', 'Youth', 'Renter', 'Transit to work', 'No English Knowledge', 'Children',
             'Visible Minority', 'LIM-AT 18-64 years', 'Median Income', 'Seniors', 'Newcomers', 'Live in single detached home',
             'LIM-AT 0-17 years', 'Drive to work', 'LIM-AT 65+ years', 'Lone Parent', '*Population']
    wide = {}
    for r in R['equity_overlay']:
        if r['attribute'] not in attrs:
            attrs.append(r['attribute'])
        wide.setdefault(r['area_id'], {})[r['attribute']] = r.get('value', '')
    write('equity_index_overlay_by_area_2021.csv', ['area_id'] + attrs,
          [[a] + [wide[a].get(k, '') for k in attrs] for a in wide])

    # Link each community to the Equity Index area that contains its 311 centrepoint
    best = {}
    for r in R['centrepoints']:
        if not r.get('comm_code'):
            continue
        c, n = r['comm_code'], int(r['n'])
        if c not in best or n > best[c][2]:
            best[c] = (r.get('latitude'), r.get('longitude'), n)
    areas = [(r['area_id'], r['multipolygon']) for r in R['equity_areas']]
    lookup = []
    for c, (lat, lon, _) in best.items():
        hit = ''
        if lat and lon:
            for area_id, mp in areas:
                if point_in_polygon(float(lon), float(lat), mp):
                    hit = area_id
                    break
        lookup.append([c, hit])
    write('community_to_area_lookup.csv', ['community_code', 'area_id'], lookup)

    write('equity_index_matrix_by_area.csv', ['area_label', 'domain', 'indicator', 'value', 'status', 'data_year'],
          [[r['csa_label'], ' '.join(r['domain_label'].split()), ' '.join(r['indicator_label'].split()), g(r, 'value'), g(r, 'status'), g(r, 'data_currency')]
           for r in R['equity_matrix']])
    comms = {}
    for r in R['equity_matrix']:
        comms.setdefault(r['csa_label'], g(r, 'communities'))
    write('equity_index_area_communities.csv', ['area_label', 'communities'], list(comms.items()))

    write('historical_community_first_year_500_residents.csv', ['community_code', 'first_census_year_500_residents'],
          [[r['comm_code'], r['first_year']] for r in R['first_year_500'] if r.get('comm_code')])
    write('property_assessments_2026_by_community.csv',
          ['community_code', 'residential_parcels', 'median_assessed_value', 'median_year_built'],
          [[g(r, 'comm_code'), r['n'], g(r, 'medval'), g(r, 'medyr')] for r in R['assessments']])
    newres = {g(r, 'communitycode'): r['n'] for r in R['permits_new_res']}
    write('building_permits_by_community_oct2024_sep2026.csv',
          ['community_code', 'permits_applied', 'housing_units', 'estimated_project_cost', 'new_residential_permits'],
          [[g(r, 'communitycode'), r['n'], g(r, 'units'), g(r, 'cost'), newres.get(g(r, 'communitycode'), 0)]
           for r in R['permits']])
    print('Saved CSVs in', OUT)


if __name__ == '__main__':
    main()
