WHO CALGARY'S 311 HEARS - study data package
Independent study. Not affiliated with The City of Calgary.
Prepared: October 21, 2026 (version 2, corrected after an independent review)

FOLDERS
01_Source_Data   Data pulled from City of Calgary Open Data (Oct 20-21, 2026), one CSV per source extract.
                 SOURCES.csv lists every dataset, its ID, period, what it was used for, and the exact query.
                 download_raw_311.py re-downloads the full raw 311 records for the study period
                 (about 1 million rows) on any computer with normal internet access.
02_Analysis      community_indicators_enriched.csv - 195 communities x all indicators used in the study
                 model_results.csv - all regression results (16 models + 2 sensitivity checks), with
                   ordinary and area-clustered t-statistics
                 reanalysis_results.json - every summary figure in the report
                 reanalyze.py - the analysis; analyze.py - first-pass analysis (superseded)
                 raw/ - the extracts as the scripts read them. To re-run: python reanalyze.py (inside 02_Analysis)
03_Report        Methodology PDF and an offline copy of the interactive report page.

KEY DEFINITIONS
Study period: requests made Oct 1, 2024 to Sep 30, 2026, excluding duplicates.
Infrastructure reports: 311 requests about roads, water and sewer, and parks and trees (21 service types: 12 roads, 5 water and sewer, 4 parks and trees).
Rates: requests per 1,000 residents per year, using 2021 Census population.
Licence: City of Calgary data is published under the Open Government Licence - City of Calgary.

CORRECTIONS IN VERSION 2 (Oct 21, 2026)
Every figure was recomputed independently from the raw extracts. Headline results did not change
(39% raw gap; about 23% fewer reports after adjustment, 95% range 9-33%; equal closure speed). Fixed:
- "Calgary" column in the community profile: now the figure for all study communities together
  (total rates; household-weighted for household measures; average community size for residents).
  Previously some rows showed a simple population-weighted average or a total.
- Equity Index Matrix indicators now come from the same area as income and language for every community
  (previously linked by name, which left 17 communities blank and mixed areas for 25).
- Home values suppressed for 4 downtown communities where parking stalls and storage units dominate.
- "Open after 90 days" replaced by "study requests not yet closed" (the old figure covered all years and types).
- Matrix shares in the CSV are now in percent, like all other shares. Community names corrected (McKenzie etc.).
- Added area-clustered t-statistics and two sensitivity checks; disclosed Carrington and Livingston exclusion;
  corrected the like-for-like and population-growth wording; added verified queries to SOURCES.csv.

COMMUNITY MAP (added Oct 23, 2026)
The report now opens with an interactive map of all 313 City community areas, drawn from the City's official
boundaries at full detail. Click a community for its people, 311 requests, ward and councillor, police district,
nearest fire station, hospital, health centre, library, community hall and leisure centre, plus verified emergency
and help numbers. Distances are straight-line from the middle of the community. Map data: 01_Source_Data/
map_boundaries_services_compact.json (coordinates delta-encoded; boundaries at 1e-6 degrees).
