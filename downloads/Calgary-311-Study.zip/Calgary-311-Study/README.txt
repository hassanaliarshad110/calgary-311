WHO CALGARY'S 311 HEARS - study data package
Independent study. Not affiliated with The City of Calgary.
Prepared: October 21, 2026 (version 2, corrected after an independent review)
Updated: October 31, 2026 (version 3, scripts to rebuild the study from City of Calgary Open Data)
Updated: November 2, 2026 (version 4, the study step by step as a Python script and a notebook)

QUICKEST WAY IN: 00_Step_by_step (about 2 minutes)
  who_calgarys_311_hears.py                  The whole study in 12 numbered code blocks. Double-click it (or run
                                             py who_calgarys_311_hears.py), or open it in VS Code and run one
                                             block at a time. It downloads the data from Open Data itself and
                                             prints each result next to the published figure.
  who_calgarys_311_hears_step_by_step.ipynb  The same blocks as a notebook, with a plain-language note before each.
                                             Open it in Google Colab (File > Upload notebook) or Jupyter.
  README.txt                                 How to run both, and the list of the 12 steps.

REPRODUCE THE STUDY (about 15 minutes)
Needs Python 3.10 or newer with pandas and numpy, and normal internet access to data.calgary.ca.
On Windows, type py instead of python. Run these inside this folder:

  1. python -m pip install pandas numpy     (once per computer)
  2. python download_data.py                (downloads all 16 source extracts from Open Data into 01_Source_Data,
                                             about 1 minute; raw responses are kept in 01_Source_Data/api_responses)
  3. python build_inputs.py                 (turns the CSVs into the inputs in 02_Analysis/raw)
  4. cd 02_Analysis
     python reanalyze.py                    (the analysis, 2-3 minutes; writes reanalysis.json and communities_enriched.csv)
     cd ..
  5. python check_results.py                (compares your run with the published figures)

To reproduce the published figures exactly, skip step 2: the extracts in 01_Source_Data are the ones the study used
(downloaded October 20-21, 2026), and all 756 values in reanalysis_results.json come out identical.
A fresh download in step 2 gives the same findings, but some counts differ slightly because Open Data is live:
requests are closed, re-coded or merged as duplicates after the fact, and the property roll changes every January.
Step 2 replaces the packaged extracts; unzip the package again to get them back.
Checked on October 31, 2026: every finding identical (39.3% raw gap; 22.7% adjusted, 95% range 8.7-32.8%; 23.0% on
true defects only; app shares; speed index), with 809,532 requests instead of 809,528 and shares closed within
7 days 0.1-0.2 points lower, because more requests had been closed by then.

FOLDERS
00_Step_by_step  The study step by step (see QUICKEST WAY IN above).
download_data.py, build_inputs.py, check_results.py   The three scripts above.
01_Source_Data   Data pulled from City of Calgary Open Data (Oct 20-21, 2026), one CSV per source extract.
                 SOURCES.csv lists every dataset, its ID, period, what it was used for, and the exact query
                 (the same queries download_data.py runs).
                 download_raw_311.py re-downloads the full raw 311 records for the study period
                 (about 1 million rows) on any computer with normal internet access.
02_Analysis      community_indicators_enriched.csv - 195 communities x all indicators used in the study
                 model_results.csv - all regression results (16 models + 2 sensitivity checks), with
                   ordinary and area-clustered t-statistics
                 reanalysis_results.json - every summary figure in the report
                 reanalyze.py - the analysis; analyze.py - first-pass analysis (superseded)
                 raw/ - the extracts as the analysis reads them (rebuilt from 01_Source_Data by build_inputs.py)
03_Report        Report to The City of Calgary (PDF) and the methodology PDF.

KEY DEFINITIONS
Study period: requests made Oct 1, 2024 to Sep 30, 2026, excluding duplicates.
Infrastructure reports: 311 requests about roads, water and sewer, and parks and trees (21 service types: 12 roads, 5 water and sewer, 4 parks and trees).
Rates: requests per 1,000 residents per year, using 2021 Census population.
Licence: City of Calgary data is published under the Open Government Licence - City of Calgary.

CORRECTIONS IN VERSION 2 (Oct 21, 2026)
Every figure was recomputed independently from the raw extracts. Headline results did not change
(39% raw gap; about 23% fewer reports after adjustment, 95% range 9-33%; equal closure speed). Fixed:
- "Calgary" column in the community profile: now the figure for all study communities together
  (total rates; household-weighted for household measures; average community size for residents).
  Previously some rows showed a simple population-weighted average or a total.
- Equity Index Matrix indicators now come from the same area as income and language for every community
  (previously linked by name, which left 17 communities blank and mixed areas for 25).
- Home values suppressed for 4 downtown communities where parking stalls and storage units dominate.
- "Open after 90 days" replaced by "study requests not yet closed" (the old figure covered all years and types).
- Matrix shares in the CSV are now in percent, like all other shares. Community names corrected (McKenzie etc.).
- Added area-clustered t-statistics and two sensitivity checks; disclosed Carrington and Livingston exclusion;
  corrected the like-for-like and population-growth wording; added verified queries to SOURCES.csv.

COMMUNITY MAP (added Oct 23, 2026)
The report now opens with an interactive map of all 313 City community areas, drawn from the City's official
boundaries at full detail. Click a community for its people, 311 requests, ward and councillor, police district,
nearest fire station, hospital, health centre, library, community hall and leisure centre, plus verified emergency
and help numbers. Distances are straight-line from the middle of the community. Map data: 01_Source_Data/
map_boundaries_services_compact.json (coordinates delta-encoded; boundaries at 1e-6 degrees).

CHANGES IN VERSION 3 (Oct 31, 2026)
- Added download_data.py, build_inputs.py and check_results.py, so the whole study can be rebuilt from Open Data.
- SOURCES.csv queries now include $limit=50000. Without it the Open Data API returns only its first 1,000 rows,
  so the earlier links, opened directly, gave incomplete extracts (the packaged extracts themselves were complete).
- SOURCES.csv now lists the second building-permits query (new residential permits: class Residential, work New),
  the Equity Index area outlines used to link communities to areas, and an end date (Sep 30, 2026) on the
  centrepoint query. No results changed.

CHANGES IN VERSION 4 (Nov 2, 2026)
- Added 00_Step_by_step: the whole study in 12 numbered blocks (communities, rates, four groups, communities of
  similar age, income and language side by side, the fair-comparison model, 1,000 bootstrap re-runs, every
  request type, closing speed, app use, Ward 5, and what the results do and don't show), as one Python script and
  as a Jupyter / Google Colab notebook. Run on the packaged extracts, every figure matches the published one.
  No results changed.
