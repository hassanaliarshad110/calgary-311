"""Step 2 of the reproduction: turn the source CSVs in 01_Source_Data into the inputs that
02_Analysis/reanalyze.py reads (02_Analysis/raw/A.json, B.json, C.json, X.json, age.txt).

Usage (from the package folder):  python build_inputs.py
Optional: python build_inputs.py <source_folder> <raw_output_folder>
"""
import csv, json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, '01_Source_Data')
OUT = sys.argv[2] if len(sys.argv) > 2 else os.path.join(HERE, '02_Analysis', 'raw')
os.makedirs(OUT, exist_ok=True)

# The 30 study service types, in the order reanalyze.py indexes them (0-20 = infrastructure).
S = ["Roads - Pothole Maintenance", "Roads - Streetlight Maintenance", "Roads - Traffic or Pedestrian Light Repair",
     "Roads - Sidewalk - Curb and Gutter Repair", "Roads - Roadway Maintenance", "Roads - Backlane Maintenance",
     "Roads - Debris on Street/Sidewalk/Boulevard", "Roads - Signs - Missing - Damaged", "Roads - Snow and Ice Control",
     "Roads - Dead Animal Pick-Up", "Roads - Pathway Concerns", "Roads - Pathway Snow and Ice Concerns",
     "WATS - Catch Basin Concerns", "WATS - Sewage Back-up", "WATS - Sewer Maintenance", "WATS - Water Main Break or Leak",
     "WATS - Service and Main Valve Issues", "Parks - Tree Concern - GIS", "Parks - Garbage - GIS", "Parks - Maintenance - GIS",
     "Parks - Infrastructure - GIS", "Corporate - Graffiti Concerns", "Corporate - Encampment Concerns",
     "Bylaw - Snow and Ice on Sidewalk", "Bylaw - Long Grass - Weeds Infraction", "Bylaw - Material on Public Property",
     "WRS - Cart Management", "WRS - Waste - Residential", "WRS - Recycling - Blue Cart", "WRS - Compost - Green Cart"]
IDX = {s: i for i, s in enumerate(S)}


def rows(name):
    with open(os.path.join(SRC, name), encoding='utf-8', newline='') as f:
        return list(csv.DictReader(f))


def blank(x):
    return None if x == '' else x


def num(x):
    """Numbers as the analysis expects: int when whole, float otherwise, None when blank."""
    if x is None or x == '':
        return None
    v = float(x)
    return int(v) if v.is_integer() else v


# ---------- A: closed requests by community, service type and year ----------
A = []
for r in rows('311_closed_requests_by_community_service_year.csv'):
    if r['service_name'] not in IDX:
        continue
    A.append([r['community_code'], IDX[r['service_name']], int(r['request_year']), int(r['closed_requests']),
              num(r['median_days_to_close']), num(r['mean_days_to_close']), int(r['closed_within_7_days']),
              int(r['closed_within_30_days']), int(r['took_over_90_days'])])

# ---------- B: request counts ----------
B = {
    'b1': [[r['community_code'], IDX[r['service_name']], int(r['requests'])]
           for r in rows('311_requests_by_community_service.csv') if r['service_name'] in IDX],
    'b2': [[r['community_code'], r['channel'], int(r['requests'])] for r in rows('311_requests_by_community_channel.csv')],
    'b3': [[r['community_code'], r['community_name'], num(r['centrepoint_latitude']), num(r['centrepoint_longitude']),
            int(r['requests_2025_onward'])] for r in rows('311_community_centrepoints.csv')],
    'b4': [[r['community_code'], int(r['request_year']), int(r['requests'])] for r in rows('311_requests_by_community_year.csv')],
}

# ---------- C: communities, area lookup, Equity Index area values, population ----------
comms = {}
for code, name, lat, lon, n in B['b3']:   # each community's centrepoint = its most-used 311 location since 2025
    if code not in comms or n > comms[code]['n']:
        comms[code] = {'name': name, 'lat': lat, 'lon': lon, 'n': n}
ind = {}
for r in rows('equity_index_overlay_by_area_2021.csv'):
    area = r.pop('area_id')
    ind[area] = {k: num(v) for k, v in r.items()}
C = {
    'comms': comms,
    'map': {r['community_code']: blank(r['area_id']) for r in rows('community_to_area_lookup.csv')},
    'ind': ind,
    'pop': [[r['community_code'], r['community_name'], num(r['population_2021'])]
            for r in rows('census2021_population_by_community.csv')],
}

# ---------- X: other community and area indicators ----------
def keep(r, cols):
    return {c: blank(r[c]) for c in cols}

X = {
    'csaComms': {r['area_label']: r['communities'] for r in rows('equity_index_area_communities.csv')},
    'cei': [[r['area_label'], r['domain'], r['indicator'], num(r['value']), r['status'], r['data_year']]
            for r in rows('equity_index_matrix_by_area.csv')],
    'permits': [{'c': r['community_code'], 'n': blank(r['permits_applied']), 'units': blank(r['housing_units']),
                 'cost': blank(r['estimated_project_cost']), 'newres': blank(r['new_residential_permits'])}
                for r in rows('building_permits_by_community_oct2024_sep2026.csv')],
    'assess': [{'c': r['community_code'], 'n': blank(r['residential_parcels']), 'medval': blank(r['median_assessed_value']),
                'medyr': blank(r['median_year_built'])} for r in rows('property_assessments_2026_by_community.csv')],
    'openold': [{'c': r['community_code'], 'n': blank(r['open_requests_older_than_90_days'])}
                for r in rows('311_open_requests_over_90_days_by_community.csv')],
    'fam': [keep(r, ['community_code', 'total_private_households', 'avg_household_size', 'house_size_1_percent',
                     'one_parent_families_per', 'married_with_children_per']) for r in rows('census2021_households_by_community.csv')],
    'emp': [keep(r, ['community_code', 'labour_participation_rate', 'unemployment_rate_per', 'employment_rate_per',
                     'top_1_industry', 'top_1_occupation']) for r in rows('census2021_employment_by_community.csv')],
    'popage': [keep(r, ['community_code', 'total_pop_household', 'pop_age_0_to_14_percent', 'pop_age_65_to_84_percent',
                        'pop_age_85_and_over_percent']) for r in rows('census2021_age_by_community.csv')],
}

age = ','.join(f"{r['community_code']} {r['first_census_year_500_residents']}"
               for r in rows('historical_community_first_year_500_residents.csv'))

for name, obj in [('A', A), ('B', B), ('C', C), ('X', X)]:
    with open(os.path.join(OUT, name + '.json'), 'w', encoding='utf-8') as f:
        json.dump(obj, f)
with open(os.path.join(OUT, 'age.txt'), 'w', encoding='utf-8') as f:
    f.write(age)
print(f"Built inputs in {OUT}: {len(A)} closed-request rows, {len(B['b1'])} request-count rows, "
      f"{len(comms)} communities, {len(ind)} Equity Index areas")
