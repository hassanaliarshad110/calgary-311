"""Step 4 of the reproduction: compare your run with the figures published in the report.

Usage (from the package folder, after running 02_Analysis/reanalyze.py):  python check_results.py
Reads 02_Analysis/reanalysis.json (your run) and 02_Analysis/reanalysis_results.json (the published run).
"""
import json, os

HERE = os.path.dirname(os.path.abspath(__file__))
A = os.path.join(HERE, '02_Analysis')
mine = json.load(open(os.path.join(A, 'reanalysis.json'), encoding='utf-8'))
pub = json.load(open(os.path.join(A, 'reanalysis_results.json'), encoding='utf-8'))

M2 = 'M2 + community age (first census year)'
DEF = 'Defects only (no snow, debris, dead animals, park garbage)'
CHECKS = [
    ('Communities in the study', lambda r: r['n_comm']),
    ('Residents, 2021 Census', lambda r: r['pop']),
    ('311 requests, all types, non-duplicate', lambda r: r['req_all']),
    ('311 requests, 30 study types', lambda r: r['req30']),
    ('Closed requests, 30 study types', lambda r: r['closed']),
    ('Raw gap in infrastructure reports, most vs fewest non-English (%)', lambda r: r['rawgap']),
    ('Infrastructure reports per 1,000 a year, fewest non-English quarter', lambda r: r['neq']['1']['rate']),
    ('Infrastructure reports per 1,000 a year, most non-English quarter', lambda r: r['neq']['4']['rate']),
    ('Adjusted gap, main model M2 (%)', lambda r: r['effects'][M2]),
    ('Adjusted gap, 95% range (%)', lambda r: f"{r['bootstrap_M2']['eff_lo']} to {r['bootstrap_M2']['eff_hi']}"),
    ('Adjusted gap, true defects only (%)', lambda r: r['sens'][DEF]['eff']),
    ('Speed index, 7 days, by income group (100 = citywide)', lambda r: [r['closure_inc'][k]['r7'] for k in '12345']),
    ('Closed within 7 days, most non-English quarter (%)', lambda r: r['closure_ne']['4']['p7']),
    ('Closed within 7 days, fewest non-English quarter (%)', lambda r: r['closure_ne']['1']['p7']),
    ('Made through the app, most non-English quarter (%)', lambda r: r['app_ne']['4']),
    ('Made through the app, fewest non-English quarter (%)', lambda r: r['app_ne']['1']),
    ('Made through the app, all study communities (%)', lambda r: round(r['city']['app_share'], 1)),
]

print(f"{'Figure':70s} {'Published':>22s} {'Your run':>22s}")
same = 0
for name, f in CHECKS:
    p, m = f(pub), f(mine)
    ok = str(p) == str(m)
    same += ok
    print(f"{name:70s} {str(p):>22s} {str(m):>22s}  {'same' if ok else 'DIFFERENT'}")
models = [k for k in pub['effects'] if pub['effects'][k] != mine['effects'].get(k)]
print(f"\nAll {len(pub['effects'])} model versions identical." if not models else f"\nModels that differ: {models}")
print(f"{same} of {len(CHECKS)} headline figures identical.")


def flat(d, p=''):
    out = {}
    if isinstance(d, dict):
        for k, v in d.items():
            out.update(flat(v, p + '/' + str(k)))
    elif isinstance(d, list):
        for i, v in enumerate(d):
            out.update(flat(v, p + '/' + str(i)))
    else:
        out[p] = d
    return out


a, b = flat(pub), flat(mine)
diff = [k for k in a if str(a[k]) != str(b.get(k))]
print(f"Every value in the results file: {len(a) - len(diff)} of {len(a)} identical.")
